//======================================================================
//  dds_osc.v  --  DDS 波表振荡器（单声部）
//
//  相位累加器(32bit) -> 取高 10 位查正弦表 -> 16bit 有符号输出
//  相位截断到 10 位，杂散约 -60dB，对听觉影响可忽略
//
//  音高公式：phase_inc = f_out * 2^32 / fs
//  例：440Hz @ fs=46875 -> 440 * 2^32 / 46875 = 40315426
//
//  后续扩展：多个本模块实例 + 时分复用查表 = 多复音
//======================================================================
module dds_osc (
    input  wire               clk,
    input  wire               rst_n,
    input  wire               tick,        // 1 clk 脉冲，每个采样周期一次
    input  wire [31:0]        phase_inc,   // 频率控制字
    output wire signed [15:0] wave
);

    reg [31:0] phase;

    always @(posedge clk or negedge rst_n)
        if (!rst_n)    phase <= 32'd0;
        else if (tick) phase <= phase + phase_inc;

    sine_rom u_rom (
        .clk  (clk),
        .addr (phase[31:22]),   // 取高 10 位 -> 1024 点波表
        .dout (wave)
    );

endmodule
