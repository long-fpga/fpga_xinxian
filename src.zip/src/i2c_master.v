//======================================================================
//  i2c_master.v  --  字节级 I2C 主控（只做"写"，够驱动 SSD1306）
//
//  为什么是"字节级"而不是"完整事务级"：
//    上层要发的是"一串字节"，中间不要 STOP、末尾才 STOP。所以这个模块
//    只负责【发一个字节 + 收 ACK】，由上层决定什么时候再发下一个、什么时候停。
//    这样上层不用管 I2C 的位时序，而这个模块也不用管业务。
//
//  ---- 开漏怎么实现 ----
//    I2C 的两根线都是"只有拉低和释放两种状态"，靠上拉电阻回到高。
//    这里直接用三态：`scl = scl_low ? 1'b0 : 1'bz;`，
//    不去依赖 cst 里的 OPEN_DRAIN 属性 —— 三态写法在任何综合器上行为都一样，
//    而且仿真里好建模（测试台加个上拉就行）。
//
//  ---- 时序 ----
//    一个位拆成 4 个"四分之一周期"，每拍 DIVQ 个时钟：
//      q0: SCL 低，把本位放到 SDA 上（数据必须在 SCL 上升沿【之前】稳定）
//      q1: 释放 SCL -> 从机在上升沿采样
//      q2: SCL 高（数据有效期）
//      q3: 拉低 SCL，准备下一位
//    27MHz / (4 x 17) ≈ 397kHz，SSD1306 支持到 400kHz。
//
//  ---- 上层的用法 ----
//      wait(!busy);
//      go <= 1; byte_in <= b; stop_after <= 是不是最后一个字节;   // 一拍脉冲
//      ... 等 done 脉冲 ...
//    ★ go 只在空闲时有效，忙的时候给会被丢掉。
//======================================================================
module i2c_master #(
    // 1/4 位周期的时钟数。17 -> 27MHz/(4*17) ≈ 397kHz
    parameter [7:0] DIVQ = 8'd17
)(
    input  wire       clk,
    input  wire       rst_n,

    // ---- 命令接口 ----
    input  wire       go,           // 一拍脉冲：开始发一个字节（只在 !busy 时有效）
    input  wire       stop_after,   // 本字节发完【之后】发 STOP（在 go 那一拍给出）
    input  wire [7:0] byte_in,      // 要发的字节

    // ---- 状态回报 ----
    output reg        busy,
    output reg        ack_err,      // 从机没给 ACK（高 = 没应答）
    output reg        done,         // 一拍脉冲：本字节（含 STOP）做完了

    // ---- I2C 总线 ----
    output wire       scl,          // 三态：0 = 拉低，z = 释放（靠上拉回高）
    output wire       sda,
    input  wire       sda_in        // 总线上 SDA 的实际电平（和 sda 接同一个 pad）
);

    // 状态
    localparam [2:0] S_IDLE  = 3'd0,
                     S_START = 3'd1,
                     S_DATA  = 3'd2,
                     S_ACK   = 3'd3,
                     S_STOP  = 3'd4,
                     S_DONE  = 3'd5,
                     S_HOLD  = 3'd6;
    //  ★ S_HOLD 是【一个事务中间】的等待态：SCL 保持低、SDA 释放，
    //    等上层给下一个字节。
    //    踩过的坑：原来每个字节发完都回 S_IDLE（把总线整个释放），
    //    下一个字节就变成了一次【新的 START】——
    //    27 个字节的初始化序列被拆成 27 次独立事务。
    //    抓包看到的症状是"事务数 = 字节数，每个事务只有 1 个字节"。
    //    （真机上很多 SSD1306 能容忍，但那是运气，不是协议。）

    reg [2:0] st;
    reg [1:0] ph;          // 0..3 四分之一位周期
    reg [2:0] bitc;        // 已发了几位（0..7）
    reg [7:0] sh;          // 发送移位寄存器（MSB 先出）
    reg       scl_low;
    reg       sda_low;
    reg       sto;         // 本字节之后要不要 STOP

    //------------------------------------------------------------------
    //  1/4 位周期节拍
    //------------------------------------------------------------------
    reg [7:0] divc;
    wire      qtick = (divc == DIVQ - 8'd1);

    always @(posedge clk or negedge rst_n)
        if (!rst_n) divc <= 8'd0;
        else        divc <= qtick ? 8'd0 : divc + 8'd1;

    //------------------------------------------------------------------
    //  开漏：只拉低或释放
    //------------------------------------------------------------------
    assign scl = scl_low ? 1'b0 : 1'bz;
    assign sda = sda_low ? 1'b0 : 1'bz;

    //------------------------------------------------------------------
    //  主状态机
    //------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st      <= S_IDLE;
            ph      <= 2'd0;
            bitc    <= 3'd0;
            sh      <= 8'd0;
            scl_low <= 1'b0;
            sda_low <= 1'b0;
            sto     <= 1'b0;
            busy    <= 1'b0;
            ack_err <= 1'b0;
            done    <= 1'b0;
        end else begin
            done <= 1'b0;               // 默认拉低，只在 S_DONE 抬一拍

            if (st == S_IDLE) begin
                // 空闲：两根线都释放，总线是高的
                scl_low <= 1'b0;
                sda_low <= 1'b0;
                busy    <= 1'b0;
                if (go) begin
                    sh      <= byte_in;
                    sto     <= stop_after;
                    // START 的前半步：SCL 还是高的时候把 SDA 拉低。
                    // 下一步在 S_START 里再把 SCL 拉低，START 才完整。
                    sda_low <= 1'b1;
                    scl_low <= 1'b0;
                    busy    <= 1'b1;
                    ack_err <= 1'b0;
                    bitc    <= 3'd0;
                    ph      <= 2'd0;
                    st      <= S_START;
                end
            end else if (qtick) begin
                // 相位计数器：每 4 拍回到 0（除非下面显式改写）
                ph <= (ph == 2'd3) ? 2'd0 : ph + 2'd1;

                case (st)
                    //---- START 收尾：把 SCL 拉低 ----
                    S_START: begin
                        if (ph == 2'd0)      scl_low <= 1'b1;
                        else if (ph == 2'd3) begin
                            st <= S_DATA;
                            ph <= 2'd0;
                        end
                    end

                    //---- 发 8 位，MSB 先出 ----
                    S_DATA: begin
                        case (ph)
                            2'd0: sda_low <= ~sh[7];    // SCL 低时换数据
                            2'd1: scl_low <= 1'b0;      // 释放 SCL，从机在上升沿采样
                            2'd2: ;                     // SCL 高，数据有效
                            default: begin              // 2'd3
                                scl_low <= 1'b1;        // 拉低 SCL
                                sh      <= {sh[6:0], 1'b0};
                                if (bitc == 3'd7) st <= S_ACK;
                                else              bitc <= bitc + 3'd1;
                            end
                        endcase
                    end

                    //---- 第 9 位：收 ACK ----
                    S_ACK: begin
                        case (ph)
                            2'd0: sda_low <= 1'b0;      // 释放 SDA，让从机去驱动
                            2'd1: scl_low <= 1'b0;      // 释放 SCL
                            2'd2: ack_err <= sda_in;    // SCL 高时采样：从机拉低 = ACK
                            default: begin              // 2'd3
                                scl_low <= 1'b1;
                                if (sto) begin
                                    st <= S_STOP;
                                end else begin
                                    // 还有后续字节：给上层一个 done，
                                    // 然后停在 S_HOLD 等它把下一个字节交过来
                                    done <= 1'b1;
                                    busy <= 1'b0;
                                    st   <= S_HOLD;
                                end
                                ph <= 2'd0;
                            end
                        endcase
                    end

                    //---- 事务中间：SCL 低、SDA 释放，等下一个字节 ----
                    //   ★ 不释放 SCL，所以不会产生 START；下一个字节直接接上去。
                    S_HOLD: begin
                        scl_low <= 1'b1;
                        sda_low <= 1'b0;
                        if (go) begin
                            sh      <= byte_in;
                            sto     <= stop_after;
                            busy    <= 1'b1;
                            bitc    <= 3'd0;
                            ph      <= 2'd0;
                            st      <= S_DATA;      // 【不经过 S_START】
                        end
                    end

                    //---- STOP：SCL 高的时候把 SDA 从低放回高 ----
                    S_STOP: begin
                        case (ph)
                            2'd0: sda_low <= 1'b1;      // SCL 低，先把 SDA 拉低
                            2'd1: scl_low <= 1'b0;      // 释放 SCL -> 上升
                            2'd2: sda_low <= 1'b0;      // SCL 还高时释放 SDA -> 这就是 STOP
                            default: st <= S_DONE;
                        endcase
                    end

                    //---- 收尾：给上层一个 done 脉冲 ----
                    S_DONE: begin
                        done <= 1'b1;
                        busy <= 1'b0;
                        st   <= S_IDLE;
                    end

                    default: st <= S_IDLE;
                endcase
            end
        end
    end

endmodule
