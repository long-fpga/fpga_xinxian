//======================================================================
//  i2s_tx.v  --  I2S (Philips) 格式发射机
//
//  从机：2026-11-01 起是【PCM5102A】（I2S 线路输出 DAC -> 外接有源音响）。
//        之前是板载 MAX98357A（I2S DAC + D 类功放）。
//        ★ 换成 PCM5102A 【这个文件一行都没改】—— 两者讲的都是标准 Philips I2S：
//            BCK/LRCK = 64、16 位数据左对齐、LRCK 边沿后延迟 1 个 BCK 出 MSB。
//            PCM5102A 的 SCK 脚接 GND（走它内部 PLL）时就是这个用法。
//
//  时序约定（I2S 标准）：
//    - 数据在 BCLK 下降沿更新，DAC 在上升沿采样
//    - WS 比 MSB 提前 1 个 BCLK 翻转（这就是 I2S 的 "1-bit delay"）
//    - WS 低 = 左声道，WS 高 = 右声道
//
//  ★ 为什么一帧要用 64 个 BCLK 而不是 32 ★
//  I2S 的 1bit 延迟让 16 位数据实际要占 17 个 slot：
//      slot 0 = 空(延迟), slot 1~16 = 数据
//  如果一帧只有 32 个 slot（每声道 16 个），数据就会越过 WS 边界，
//  DAC 按 WS 边沿数 16 位时最后一位会错位 —— 实测解码值正好差一倍。
//  改成 64 slot/帧后，数据区 slot 1~16 完全落在 WS 低电平的 0~31 内，
//  右声道同理落在 33~48（WS 高电平 32~63 内），时序就无歧义了。
//
//  时钟：BCLK = clk / 9 = 3MHz
//        一帧   = 64 BCLK
//        fs     = 3MHz / 64 = 46875Hz   （和原来一样，音符表不用改）
//  BCLK 占空比 4:5（44%/56%），在 MAX98357A 的允许范围内。
//======================================================================
module i2s_tx (
    input  wire               clk,        // 27MHz
    input  wire               rst_n,
    input  wire signed [15:0] sample_l,   // 左声道样本
    input  wire signed [15:0] sample_r,   // 右声道样本
    output reg                bck,
    output reg                ws,
    output reg                din,
    output reg                fs_tick     // 每帧末 1 个 clk 的脉冲
);

    // ---------- BCLK 分频：27MHz / 9 = 3MHz ----------
    reg  [3:0] div_cnt;                            // 0..8
    wire [3:0] div_nxt   = (div_cnt == 4'd8) ? 4'd0 : div_cnt + 4'd1;
    wire       bclk_fall = (div_nxt == 4'd0);      // 下一拍即 BCLK 下降沿

    // ---------- 帧内位计数：一帧 64 个 BCLK ----------
    reg  [5:0] b_cnt;                              // 0..63
    reg [63:0] frame;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            div_cnt <= 4'd0;
            b_cnt   <= 6'd0;
            bck     <= 1'b0;
            ws      <= 1'b0;
            din     <= 1'b0;
            frame   <= 64'd0;
            fs_tick <= 1'b0;
        end else begin
            div_cnt <= div_nxt;
            bck     <= (div_nxt >= 4'd4);          // 低 4 拍、高 5 拍
            fs_tick <= 1'b0;

            if (bclk_fall) begin
                if (b_cnt == 6'd0) begin
                    // 每帧装载一次。布局（bit63 最先送出）：
                    //   [63:48] 左声道样本（MSB 在 63，slot 1 送出）
                    //   [47:32] 补零
                    //   [31:16] 右声道样本（移位 32 次后 MSB 到 bit63，slot 33 送出）
                    //   [15:0]  补零
                    // slot 0 送的是上一帧的残留，本来就该被 DAC 忽略（1bit 延迟）
                    frame <= {sample_l, 16'd0, sample_r, 16'd0};
                end else begin
                    frame <= {frame[62:0], 1'b0};
                end

                din <= frame[63];                  // MSB 先出

                // WS：低 32 个 slot = 左，高 32 个 slot = 右
                ws  <= (b_cnt >= 6'd32);

                if (b_cnt == 6'd63) begin
                    b_cnt   <= 6'd0;
                    fs_tick <= 1'b1;               // 通知振荡器算下一个样本
                end else begin
                    b_cnt <= b_cnt + 6'd1;
                end
            end
        end
    end

endmodule
