//======================================================================
//  keypad.v  --  4x4 按键矩阵扫描 + 消抖
//
//  只做硬件的事（扫描行列 + 消抖），不含音乐逻辑 —— 那些在 synth_top 里。
//  这样这个模块可以用测试台【电气地】驱动矩阵来验证，不用发声。
//
//  行列约定：row 输出，选中的行拉高、其余高阻；col 输入，按下 = 高。
//            第 k 个键 = row*4 + col。
//
//  ★ 未选中的行必须输出 1'bz，不能拉低 ★
//    同列两个键（一个在选中行、一个在未选中行）同时按时，拉低会构成分压，
//    列上约 1.65V < LVCMOS33 的 VIH(2.0V) -> 列被判成低 -> 【漏键】。
//    而"同列多键同按"正是弹和弦的常态。靠 PULL_MODE=DOWN 兜底就没这问题。
//    （一次只驱动一行，所以不会有 ghosting。）
//
//  时序：行槽 128us(3456 拍) -> 一帧 512us；消抖 6 帧 = 3.07ms
//        输入延迟 3.07 + 0.51(量化) = 3.58ms，赛题 10ms 上限有余量。
//======================================================================
module keypad #(
    // 一行选中的时长，单位是 clk 拍。3456 拍 / 27MHz = 128us。
    parameter [14:0] ROW_CYCLES = 15'd3455
)(
    input  wire        clk,
    input  wire        rst_n,
    output wire [3:0]  row,        // 三态输出
    input  wire [3:0]  col,        // 按下 = 高
    output wire [15:0] keys        // 消抖后的按下位图，bit k = 第 k 个键
);

    //------------------------------------------------------------------
    //  行扫描：slot_cnt 数到 ROW_CYCLES 就换下一行
    //------------------------------------------------------------------
    reg [14:0] slot_cnt;
    reg [1:0]  row_sel;
    reg [15:0] frame;          // 本轮 4 行收集到的原始位图

    wire slot_end = (slot_cnt == ROW_CYCLES);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            slot_cnt <= 15'd0;
            row_sel  <= 2'd0;
            frame    <= 16'd0;
        end else if (slot_end) begin
            slot_cnt <= 15'd0;
            // 这一行的 4 个列读数写进 frame 对应的 4 位。
            // col 在整个行槽里都稳定，所以在槽末尾采样是对的。
            case (row_sel)
                2'd0:    frame[ 3: 0] <= col;
                2'd1:    frame[ 7: 4] <= col;
                2'd2:    frame[11: 8] <= col;
                default: frame[15:12] <= col;
            endcase
            row_sel <= row_sel + 2'd1;
        end else begin
            slot_cnt <= slot_cnt + 15'd1;
        end
    end

    // 一帧扫完（row_sel 刚从 3 回到 0 的下一拍）
    reg frame_done;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) frame_done <= 1'b0;
        else        frame_done <= slot_end && (row_sel == 2'd3);
    end

    //------------------------------------------------------------------
    //  三态行驱动
    //    ★ 未选中 = 1'bz，不是 1'b0（理由见文件头）
    //    ★ 复位期间全部高阻，避免上电瞬间和按键打架
    //------------------------------------------------------------------
    assign row[0] = (rst_n && row_sel == 2'd0) ? 1'b1 : 1'bz;
    assign row[1] = (rst_n && row_sel == 2'd1) ? 1'b1 : 1'bz;
    assign row[2] = (rst_n && row_sel == 2'd2) ? 1'b1 : 1'bz;
    assign row[3] = (rst_n && row_sel == 2'd3) ? 1'b1 : 1'bz;

    //------------------------------------------------------------------
    //  消抖：6 帧连续一致才认账。
    //   96 位 = 6 个 16 位字段，每帧左移 16 位塞入新值；6 个字段在【同一位】
    //   上都是 1，那个键才算按下。
    //
    //  ★ 必须写逐位与 `a & b & c...`，不能写成归约与 `&{a,b,c...}` ——
    //    后者结果只有 1 位（96 位全 1 才给 1）。写错过一次：db_sh 六个字段
    //    明明都是 0001，输出却恒为 0。是测试台逐帧打印 db_sh 才抓出来的。
    //------------------------------------------------------------------
    reg [95:0] db_sh;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) db_sh <= 96'd0;
        else if (frame_done) db_sh <= {db_sh[79:0], frame};
    end

    assign keys = db_sh[15: 0] & db_sh[31:16] & db_sh[47:32] &
                  db_sh[63:48] & db_sh[79:64] & db_sh[95:80];

endmodule
