//======================================================================
//  oled_ssd1306.v  --  SSD1306 128x64 OLED 驱动（I2C）
//
//  干三件事：
//    ① 上电发一遍【初始化序列】（不开 charge pump 的话 4 脚模块根本不亮）
//    ② 提供一块 1024 字节显存，给 oled_ui.v 往里画
//    ③ 每隔一段时间把整块显存【刷】到屏上
//
//  ---- 显存为什么是 1024 字节 ----
//    128 列 x 64 行 = 8192 像素 = 1024 字节。SSD1306 的组织方式是
//    【列-页】：一个字节 = 一列里的 8 个竖直像素，bit0 是最上面那个。
//    所以 64 行 = 8 页，每页 128 字节。
//    ⇒ 字库也必须按列-页存（见 gen_font.py），不然会看到"字是歪的"。
//
//  ---- 刷屏怎么发 ----
//    一次 I2C 事务搞定（不要每个字节起停，那样慢十倍）：
//      [START][0x78][0x00][0xB0 0x00 0x10][0x40][1024 个数据字节][STOP]
//       0x78 = 从机地址(写)   0x00 = 后面是命令   0x40 = 后面是数据
//       0xB0 0x00 0x10 = 把地址指针设回 页0/列0（每次刷都设一遍，
//       这样万一中途出错也只是花一帧，不会永久错位）
//    1024 字节约 23ms @400kHz，按 12Hz 刷，占 I2C 带宽约 28%。
//
//  ---- 显存的读写口 ----
//    写口给 oled_ui，读口给刷屏，正好是 BSRAM 的简单双口，1 块就够。
//    ★ 不需要仲裁：oled_ui 随便什么时候写；同一拍写和读同一个地址时
//      读出来的是旧值，最多让这一帧花一下，下一帧就对了。
//======================================================================
module oled_ssd1306 #(
    // 两次刷屏之间等多少个时钟。27MHz x 0.08s ≈ 2.16M -> 12Hz
    parameter [22:0] REFRESH_CYC = 23'd2160000,
    parameter [7:0]  I2C_ADDR    = 8'h78      // SSD1306 的 0x3C 左移一位
)(
    input  wire       clk,
    input  wire       rst_n,

    // ---- 显存写口（oled_ui 用）----
    input  wire       we,
    input  wire [9:0] waddr,      // 0..1023
    input  wire [7:0] wdat,

    // ---- 状态 ----
    output reg        ready,      // 初始化序列发完了
    output reg        busy,       // 正在刷屏
    output reg        addr_ok,    // ★ 模块有没有应答 I2C 地址（诊断用）

    // ---- I2C ----
    output wire       scl,
    output wire       sda,
    input  wire       sda_in,
    output wire       ack_err     // 从机没应答（诊断用，正常应该恒为 0）
);

    //------------------------------------------------------------------
    //  初始化序列 ROM
    //    ★ 0x8D 0x14 是【开 charge pump】—— 4 脚模块（VCC/GND/SCL/SDA）
    //      没有外部升压电路，不开这个屏就是全黑。曾经在这里栽过。
    //    ★ 0x20 0x00 是【水平寻址模式】，刷屏时数据会自动 列->页 递增，
    //      1024 字节写完正好绕回开头。
    //------------------------------------------------------------------
    reg [7:0] init_rom [0:31];
    initial begin
        init_rom[ 0] = 8'hAE;   // display OFF
        init_rom[ 1] = 8'hD5;   // 时钟分频 / 振荡频率
        init_rom[ 2] = 8'h80;
        init_rom[ 3] = 8'hA8;   // 多路复用率
        init_rom[ 4] = 8'h3F;   //   64 行 -> 0x3F
        init_rom[ 5] = 8'hD3;   // 显示偏移
        init_rom[ 6] = 8'h00;
        init_rom[ 7] = 8'h40;   // 起始行 = 0
        init_rom[ 8] = 8'h8D;   // ★ charge pump
        init_rom[ 9] = 8'h14;   //   ★ 0x14 = 开
        init_rom[10] = 8'h20;   // ★ 寻址模式
        init_rom[11] = 8'h00;   //   ★ 0x00 = 水平
        init_rom[12] = 8'hA1;   // 段重映射（列 127 -> SEG0）
        init_rom[13] = 8'hC8;   // COM 扫描方向反向
        init_rom[14] = 8'hDA;   // COM 引脚配置
        init_rom[15] = 8'h12;   //   128x64 用 0x12
        init_rom[16] = 8'h81;   // 对比度
        init_rom[17] = 8'hCF;
        init_rom[18] = 8'hD9;   // 预充电周期
        init_rom[19] = 8'hF1;
        init_rom[20] = 8'hDB;   // VCOMH 电平
        init_rom[21] = 8'h40;
        init_rom[22] = 8'hA4;   // 显示内容跟随显存
        init_rom[23] = 8'hA6;   // 正常显示（非反色）
        init_rom[24] = 8'hAF;   // display ON
        init_rom[25] = 8'h00;
        init_rom[26] = 8'h00;
        init_rom[27] = 8'h00;
        init_rom[28] = 8'h00;
        init_rom[29] = 8'h00;
        init_rom[30] = 8'h00;
        init_rom[31] = 8'h00;
    end
    localparam [5:0] INIT_N = 6'd25;      // 真正要发的命令字节数

    //------------------------------------------------------------------
    //  显存 1024 x 8 = 1 块 BSRAM（单写口 + 单读口）
    //------------------------------------------------------------------
    reg [7:0]  mem [0:1023];
    reg [7:0]  dout;
    reg [9:0]  raddr;

    always @(posedge clk) begin
        if (we) mem[waddr] <= wdat;
        dout <= mem[raddr];
    end

    //------------------------------------------------------------------
    //  刷屏间隔计数
    //------------------------------------------------------------------
    reg [22:0] refc;
    wire       refresh_now = (refc == REFRESH_CYC);
    always @(posedge clk or negedge rst_n)
        if (!rst_n)      refc <= 23'd0;
        else if (refresh_now) refc <= 23'd0;
        else             refc <= refc + 23'd1;

    //------------------------------------------------------------------
    //  事务编排
    //    phase = 0：初始化（只做一次）
    //    phase = 1：刷屏
    //    n = 本事务里第几个字节（含地址字节和控制字节）
    //------------------------------------------------------------------
    localparam [1:0] P_PROBE = 2'd0,
                     P_INIT  = 2'd1,
                     P_IDLE  = 2'd2,
                     P_FLUSH = 2'd3;

    //------------------------------------------------------------------
    //  I2C 地址
    //    默认 0x3C（左移一位 = 0x78）。模块是 0x3D 的话直接改这个参数重综合。
    //    ★ 曾经想做成"0x3C 不应答就自动换 0x3D"，但那把事务结构改坏了
    //      （见下面 P_INIT 的注释）。边缘情况不值得拿一个验过的设计去换。
    //------------------------------------------------------------------
    reg [7:0] addr;

    reg [1:0]  phase;
    reg [10:0] n;
    //  ★ settling：字节之间插一拍。
    //    显存的读是【寄存输出】（`dout <= mem[raddr]`，慢一拍），而 raddr 是由 n
    //    组合出来的。上层在 n 刚加一的那一拍就把 dout 交出去的话，
    //    交出去的还是【上一个地址】的数据 —— 整个画面会整体错位一个字节。
    //    抓包看到的症状：显存里 1024 个字节有 191 个不一致，而且
    //    `实际[i] == 期望[i-1]`（整条流延迟了一个字节）。
    reg        settling;

    // 刷屏事务：n=0..5 是地址/控制，n=6..1029 是 1024 个显存字节
    wire [10:0] FB_N0 = 11'd6;
    wire [10:0] FB_NL = 11'd1029;

    wire [7:0] tx_byte =
        (phase == P_PROBE) ? addr :                       // 探测：只发一个地址字节
        (phase == P_INIT) ?
            ((n == 11'd0) ? addr :
             (n == 11'd1) ? 8'h00 :
             (n >= 11'd2 && n < 11'd2 + {5'd0, INIT_N}) ? init_rom[n - 11'd2] : 8'h00)
        :
            ((n == 11'd0) ? addr   :
             (n == 11'd1) ? 8'h00   :
             (n == 11'd2) ? 8'hB0   :   // 页 0
             (n == 11'd3) ? 8'h00   :   // 列低 4 位 = 0
             (n == 11'd4) ? 8'h10   :   // 列高 4 位 = 0
             (n == 11'd5) ? 8'h40   :   // 后面是数据
             dout);

    wire tx_last = (phase == P_PROBE) ? (n == 11'd0) :
                   (phase == P_INIT)  ? (n == 11'd1 + {5'd0, INIT_N}) :
                                        (n == FB_NL);

    // 显存读地址：只有刷屏的数据段才递增
    //   ★ n - FB_N0 的范围是 0..1023（n 走 6..1029），10 位装得下，
    //     但表达式本身是 11 位，直接赋值综合器会报 EX3791"截断"。
    //     先存到 11 位的中间变量再取低 10 位 —— 这个项目出过"静默截断"的事。
    //   ★ 注意不能写 `(n - FB_N0)[9:0]`：那是 SystemVerilog 语法，
    //     Verilog-2001 不接受，iverilog 会直接报 syntax error。
    wire [10:0] rd_off = n - FB_N0;

    always @* begin
        if (phase == P_FLUSH && n >= FB_N0 && n <= FB_NL)
            raddr = rd_off[9:0];
        else
            raddr = 10'd0;
    end

    //------------------------------------------------------------------
    //  I2C 主控
    //------------------------------------------------------------------
    reg        i2c_go;
    reg        i2c_stop;
    reg [7:0]  i2c_byte;
    wire       i2c_busy, i2c_done;

    i2c_master u_i2c (
        .clk        (clk),
        .rst_n      (rst_n),
        .go         (i2c_go),
        .stop_after (i2c_stop),
        .byte_in    (i2c_byte),
        .busy       (i2c_busy),
        .ack_err    (ack_err),
        .done       (i2c_done),
        .scl        (scl),
        .sda        (sda),
        .sda_in     (sda_in)
    );

    //------------------------------------------------------------------
    //  编排状态机
    //------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            phase    <= P_INIT;
            n        <= 11'd0;
            addr     <= I2C_ADDR;
            addr_ok  <= 1'b0;
            i2c_go   <= 1'b0;
            i2c_stop <= 1'b0;
            i2c_byte <= 8'd0;
            ready    <= 1'b0;
            busy     <= 1'b0;
            settling <= 1'b0;
        end else begin
            i2c_go <= 1'b0;

            // 上一字节刚结束的那一拍不动，等显存读数落定
            if (i2c_done)   settling <= 1'b1;
            else            settling <= 1'b0;

            case (phase)
                //---- 初始化：一整个事务发完 25 条命令 ----
                P_INIT: begin
                    if (!i2c_busy && !i2c_go && !settling) begin
                        i2c_byte <= tx_byte;
                        i2c_stop <= tx_last;
                        i2c_go   <= 1'b1;
                    end
                    if (i2c_done) begin
                        // ★ 第一个字节就是【从机地址】。它有没有被应答，
                        //   直接说明"I2C 到底通没通"——报给 led[4] 做诊断。
                        //   （比单独发一个探测字节好：不动事务结构，
                        //     用的是本来就要发的那个字节。）
                        if (n == 11'd0) addr_ok <= ~ack_err;
                        if (tx_last) begin
                            phase <= P_IDLE;
                            ready <= 1'b1;
                            n     <= 11'd0;
                        end else begin
                            n <= n + 11'd1;
                        end
                    end
                end

                //---- 空闲：等刷新节拍 ----
                P_IDLE: begin
                    n <= 11'd0;
                    if (refresh_now) begin
                        phase <= P_FLUSH;
                        busy  <= 1'b1;
                    end
                end

                //---- 刷屏：一个事务发 0x78/0x00/地址/0x40 + 1024 字节 ----
                P_FLUSH: begin
                    if (!i2c_busy && !i2c_go && !settling) begin
                        i2c_byte <= tx_byte;
                        i2c_stop <= tx_last;
                        i2c_go   <= 1'b1;
                    end
                    if (i2c_done) begin
                        if (tx_last) begin
                            phase <= P_IDLE;
                            busy  <= 1'b0;
                            n     <= 11'd0;
                        end else begin
                            n <= n + 11'd1;
                        end
                    end
                end

                default: phase <= P_INIT;
            endcase
        end
    end

endmodule
