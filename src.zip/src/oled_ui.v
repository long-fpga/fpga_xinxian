//======================================================================
//  oled_ui.v  --  把要显示的内容排进显存
//
//  布局（128x64，16x16 字格 -> 每行 8 格，共 4 行）：
//    行1 (page 0-1):  小 星 星                    <- 当前歌曲
//    行2 (page 2-3):  自 动  [#] [5]              <- 自动演奏的旋律音
//    行3 (page 4-5):  键 盘  [1][3][5][1]         <- 键盘最多 4 个音
//    行4 (page 6-7):  （空）
//
//  音符用【简谱数字 + 八度点】（点在上=高音，点在下=低音），和简谱写法一致。
//  升号单独占一格画 "#"，所以旋律那一行留了两格（前格放 # 或空格）。
//
//  ---- 为什么要一个"重画"状态机 ----
//    显存是 1024 字节的 BSRAM，内容变化时得把相关字格重画一遍。
//    做法最简单：变化了就【先清屏再全画一遍】（约 13 格 x 32 字节 = 416 字节，
//    每个字节 2 拍，总共约 1000 拍 = 37us）。便宜到不需要做增量更新，
//    而增量更新正是"漏刷某一格"这类 bug 的温床。
//
//  ---- 显存地址怎么算 ----
//    字号 i 在字格 (cc, rr) 里，它的第 g 个字节（g = {page, col}）写到：
//        addr = (rr*2 + page) * 128 + cc*16 + col
//    因为 SSD1306 的显存是"每页 128 字节、共 8 页"线性排布的。
//
//  ---- 提示 ----
//    这里显示的简谱一律按【1 = C】。青花瓷在你手写的谱子里是 1 = A，
//    所以它的旋律会出现 #1 / #4 / #5。要改成按曲子调性显示的话，
//    在下面的 note_pitch() 前面加一个"减去主音"的偏移就行。
//======================================================================
module oled_ui (
    input  wire       clk,
    input  wire       rst_n,

    // ---- 要显示的内容（由 synth_top 接过来）----
    input  wire [2:0] song,                          // 0=辞九门回忆 1=江南 2=青花瓷（3~7 空）
    input  wire [5:0] mel_note,                      // 锁存后的旋律音（6'h3F 无效）
    input  wire [5:0] kbd_n0, kbd_n1, kbd_n2, kbd_n3,// 键盘 4 个声部当前音
    input  wire [3:0] kbd_gate,                      // 哪几个声部在响

    // ---- 显存写口 ----
    output reg        we,
    output reg [9:0]  waddr,
    output reg [7:0]  wdat
);

    //------------------------------------------------------------------
    //  字库编号
    //  ★ 这些数字必须和 gen_font.py 的 CHARS 表顺序一致。
    //    改字表会整体挪位 —— check_oled.py 会拿 gen_font.py 重新算一遍来核对，
    //    对不上会报错，所以不用担心"改了字表忘了改这里"。
    //------------------------------------------------------------------
    localparam [5:0] C_XIAO  = 6'd0,  C_XING = 6'd1,  C_HUAN = 6'd2,
                     C_LE    = 6'd3,  C_SONG = 6'd4,  C_QING = 6'd5,
                     C_HUA   = 6'd6,  C_CI   = 6'd7,  C_ZI   = 6'd8,
                     C_DONG  = 6'd9,  C_JIAN = 6'd20, C_PAN  = 6'd21,
                     C_JIANG = 6'd22, C_NAN  = 6'd23,
                     C_CIJIU = 6'd24, C_JIU  = 6'd25, C_MEN  = 6'd26,
                     C_HUI   = 6'd27, C_YI   = 6'd28,
                     C_SHARP = 6'd39, C_SPACE= 6'd61;
    // 音符字 = 八度基址 + 简谱数字（1..7）
    // ★ 这三个（还有 C_SHARP / C_SPACE）会随 gen_font.py 的 CHARS 表挪位。
    //   上次加「江 南」两个字，音符整体后移了 2，就是靠 check_font_ids.py 抓出来的。
    localparam [5:0] NB_DI  = 6'd39,    // 低音1 的编号（所以 低音n = 39+n）
                     NB_ZH  = 6'd46,    // 中音1 的编号
                     NB_GAO = 6'd53;    // 高音1 的编号

    //------------------------------------------------------------------
    //  音符解码：{八度[1:0], 半音[3:0]} -> 简谱数字 + 升号 + 八度点
    //------------------------------------------------------------------
    function [3:0] jianpu;      // 半音 -> 简谱数字 1..7（升号取等音级，如 C# -> 1）
        input [3:0] s;
        begin
            case (s)
                4'd0,  4'd1 : jianpu = 4'd1;   // C  / C#
                4'd2,  4'd3 : jianpu = 4'd2;   // D  / D#
                4'd4        : jianpu = 4'd3;   // E
                4'd5,  4'd6 : jianpu = 4'd4;   // F  / F#
                4'd7,  4'd8 : jianpu = 4'd5;   // G  / G#
                4'd9,  4'd10: jianpu = 4'd6;   // A  / A#
                default     : jianpu = 4'd7;   // B
            endcase
        end
    endfunction

    function sharp;             // 这个半音要不要画 "#"
        input [3:0] s;
        begin
            case (s)
                4'd1, 4'd3, 4'd6, 4'd8, 4'd10: sharp = 1'b1;
                default:                       sharp = 1'b0;
            endcase
        end
    endfunction

    // 八度基址：0=C3 区 -> 低音，1=C4 区 -> 中音，>=2 -> 高音
    function [5:0] oct_base;
        input [1:0] o;
        begin
            case (o)
                2'd0:    oct_base = NB_DI;
                2'd1:    oct_base = NB_ZH;
                default: oct_base = NB_GAO;
            endcase
        end
    endfunction

    // 一个音符号 -> 该画的数字字编号（6'h3F 或非法 -> 空格）
    function [5:0] note_ch;
        input [5:0] n;
        begin
            if (n == 6'h3F) note_ch = C_SPACE;
            else            note_ch = oct_base(n[5:4]) + {2'd0, jianpu(n[3:0])};
        end
    endfunction

    // 一个音符号 -> 要不要画升号
    function note_sharp;
        input [5:0] n;
        begin
            note_sharp = (n != 6'h3F) && sharp(n[3:0]);
        end
    endfunction

    //------------------------------------------------------------------
    //  字格表（固定 13 格，位置不动，内容变）
    //    idx  0..2 : 歌曲名三个字        (列 0,1,2 / 行 0)
    //    idx  3,4  : 自 动               (列 0,1 / 行 1)
    //    idx  5    : 旋律的升号（或空格）(列 2   / 行 1)
    //    idx  6    : 旋律的音符          (列 3   / 行 1)
    //    idx  7,8  : 键 盘               (列 0,1 / 行 2)
    //    idx  9..12: 键盘 4 个音          (列 2..5/ 行 2)
    //------------------------------------------------------------------
    //  ★ `cur_cell` 必须先声明再用 —— 这个项目栽过：高云综合器容忍"用在前声明在后"，
    //    但会把信号隐式推断成 1 位线网；iverilog 会直接报错，所以改完先跑它。
    reg  [3:0] cur_cell;                        // 当前在画第几格
    wire [3:0] cell_idx = cur_cell;

    reg [5:0] cell_ch;
    reg [3:0] cell_cc, cell_rr;             // 列格号 / 行格号

    //  ★ 歌名占【5 格】：辞九门回忆是 5 个字，江南 2 个、青花瓷 3 个，不够的补空格。
    always @* begin
        case (cell_idx)
            // ---- 行0：歌名（5 格）----
            4'd0: begin cell_ch = (song == 3'd1) ? C_JIANG : (song == 3'd2) ? C_QING  : C_CIJIU;
                        cell_cc = 4'd0; cell_rr = 4'd0; end
            4'd1: begin cell_ch = (song == 3'd1) ? C_NAN   : (song == 3'd2) ? C_HUA   : C_JIU;
                        cell_cc = 4'd1; cell_rr = 4'd0; end
            4'd2: begin cell_ch = (song == 3'd1) ? C_SPACE : (song == 3'd2) ? C_CI    : C_MEN;
                        cell_cc = 4'd2; cell_rr = 4'd0; end
            4'd3: begin cell_ch = (song == 3'd1) ? C_SPACE : (song == 3'd2) ? C_SPACE : C_HUI;
                        cell_cc = 4'd3; cell_rr = 4'd0; end
            4'd4: begin cell_ch = (song == 3'd1) ? C_SPACE : (song == 3'd2) ? C_SPACE : C_YI;
                        cell_cc = 4'd4; cell_rr = 4'd0; end
            // ---- 行1：自 动 + 旋律音 ----
            4'd5: begin cell_ch = C_ZI;    cell_cc = 4'd0; cell_rr = 4'd1; end
            4'd6: begin cell_ch = C_DONG;  cell_cc = 4'd1; cell_rr = 4'd1; end
            4'd7: begin cell_ch = note_sharp(mel_note) ? C_SHARP : C_SPACE;
                        cell_cc = 4'd2; cell_rr = 4'd1; end
            4'd8: begin cell_ch = note_ch(mel_note);
                        cell_cc = 4'd3; cell_rr = 4'd1; end
            // ---- 行2：键 盘 + 键盘 4 个音 ----
            4'd9:  begin cell_ch = C_JIAN; cell_cc = 4'd0; cell_rr = 4'd2; end
            4'd10: begin cell_ch = C_PAN;  cell_cc = 4'd1; cell_rr = 4'd2; end
            4'd11: begin cell_ch = kbd_gate[0] ? note_ch(kbd_n0) : C_SPACE;
                         cell_cc = 4'd2; cell_rr = 4'd2; end
            4'd12: begin cell_ch = kbd_gate[1] ? note_ch(kbd_n1) : C_SPACE;
                         cell_cc = 4'd3; cell_rr = 4'd2; end
            4'd13: begin cell_ch = kbd_gate[2] ? note_ch(kbd_n2) : C_SPACE;
                         cell_cc = 4'd4; cell_rr = 4'd2; end
            default: begin cell_ch = kbd_gate[3] ? note_ch(kbd_n3) : C_SPACE;
                         cell_cc = 4'd5; cell_rr = 4'd2; end
        endcase
    end

    localparam [3:0] CELL_LAST = 4'd14;

    //------------------------------------------------------------------
    //  显存地址：addr = (rr*2 + page) * 128 + cc*16 + col
    //    ★ 必须先在 11 位里算完再截到 10 位，而且常数要写 8'd128。
    //      写成 `* 7'd128` 的话 128 会被截成 0（7 位最大 127），
    //      结果所有字都写到地址 0 那一块 —— 屏上只会看到一堆重叠的乱码。
    //    ★ `g` 要【先声明】再在这里用 —— 这个项目栽过两次"用在前声明在后"，
    //      高云综合器会容忍并把信号推断成 1 位线网，只有 iverilog 会报。
    //------------------------------------------------------------------
    reg [5:0] g;            // 字格内第几个字节 0..31（g[4]=page, g[3:0]=col）

    wire [10:0] cell_byte_addr = (({cell_rr, 1'b0} + {5'd0, g[4]}) * 8'd128)
                                + {cell_cc, 4'b0} + {6'd0, g[3:0]};

    //------------------------------------------------------------------
    //  字库 ROM
    //------------------------------------------------------------------
    reg  [5:0] fch;
    reg        fpage;
    reg  [3:0] fcol;
    wire [7:0] fbits;

    font_rom u_font (
        .clk  (clk),
        .ch   (fch),
        .page (fpage),
        .col  (fcol),
        .bits (fbits)
    );

    //------------------------------------------------------------------
    //  内容变化检测：变成"需要重画"
    //    把输入打一拍再比，避免组合毛刺触发重画
    //------------------------------------------------------------------
    reg [2:0] song_r;
    reg [5:0] mel_r, k0_r, k1_r, k2_r, k3_r;
    reg [3:0] gate_r;
    reg       need;

    wire content_diff = (song      != song_r) | (mel_note != mel_r)  |
                        (kbd_gate  != gate_r) |
                        (kbd_n0 != k0_r) | (kbd_n1 != k1_r) |
                        (kbd_n2 != k2_r) | (kbd_n3 != k3_r);

    //------------------------------------------------------------------
    //  重画状态机
    //    S_CLEAR: 把 1024 字节显存清 0
    //    S_ADDR : 给字库 ROM 送地址
    //    S_WR   : 把 ROM 出来的字节写进显存
    //------------------------------------------------------------------
    //                                                                    S_WAIT : 等字库读数落定
    //    S_WR   : 把 ROM 出来的字节写进显存
    //------------------------------------------------------------------
    localparam [2:0] S_IDLE = 3'd0, S_CLEAR = 3'd1, S_ADDR = 3'd2,
                     S_WAIT = 3'd3, S_WR = 3'd4;

    reg [2:0]  st;
    reg [9:0]  clr;         // 清屏计数
    reg        first;       // 上电后第一次一定要画

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st      <= S_IDLE;
            clr     <= 10'd0;
            cur_cell    <= 4'd0;
            g       <= 6'd0;
            we      <= 1'b0;
            waddr   <= 10'd0;
            wdat    <= 8'd0;
            fch     <= 6'd0;
            fpage   <= 1'b0;
            fcol    <= 4'd0;
            song_r  <= 3'd0;
            mel_r   <= 6'h3F;
            k0_r    <= 6'h3F; k1_r <= 6'h3F; k2_r <= 6'h3F; k3_r <= 6'h3F;
            gate_r  <= 4'd0;
            first   <= 1'b1;
        end else begin
            we <= 1'b0;

            case (st)
                S_IDLE: begin
                    if (first || content_diff) begin
                        // 把当前内容锁存下来，一边画一边变会导致画面撕裂
                        song_r <= song;
                        mel_r  <= mel_note;
                        k0_r   <= kbd_n0; k1_r <= kbd_n1;
                        k2_r   <= kbd_n2; k3_r <= kbd_n3;
                        gate_r <= kbd_gate;
                        first  <= 1'b0;
                        clr    <= 10'd0;
                        cur_cell   <= 4'd0;
                        g      <= 6'd0;
                        st     <= S_CLEAR;
                    end
                end

                //---- 清屏：1024 个字节写 0 ----
                S_CLEAR: begin
                    we    <= 1'b1;
                    waddr <= clr;
                    wdat  <= 8'd0;
                    if (clr == 10'd1023) st <= S_ADDR;
                    else                 clr <= clr + 10'd1;
                end

                //---- 给字库送地址 ----
                S_ADDR: begin
                    fch   <= cell_ch;
                    fpage <= g[4];
                    fcol  <= g[3:0];
                    st    <= S_WAIT;
                end

                //---- ★ 空等一拍 ★ ----
                //   字库是【寄存输出】：S_ADDR 那一拍设了地址，数据要【下一拍】才出来。
                //   如果 S_ADDR 之后直接进 S_WR，wdat 拿到的还是【上一个地址】的数据
                //   —— 整个画面会整体错位一个字节。
                //   症状：1024 个字节里 191 个不一致，且 `实际[i] == 期望[i-1]`
                //   （整条流延迟一个字节）。是单独跑 oled_ui 才定位到的
                //   —— 整套一起跑要 5 分钟，单独跑只要 2 秒。
                S_WAIT: st <= S_WR;

                //---- 收数据、写显存 ----
                S_WR: begin
                    we    <= 1'b1;
                    waddr <= cell_byte_addr[9:0];
                    wdat  <= fbits;
                    if (g == 6'd31) begin
                        g <= 6'd0;
                        if (cur_cell == CELL_LAST) st <= S_IDLE;
                        else begin
                            cur_cell <= cur_cell + 4'd1;
                            st   <= S_ADDR;
                        end
                    end else begin
                        g  <= g + 6'd1;
                        st <= S_ADDR;
                    end
                end

                default: st <= S_IDLE;
            endcase
        end
    end

endmodule
