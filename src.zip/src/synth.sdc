#=====================================================================
#  synth.sdc -- 时序约束
#
#  为什么需要这个：
#    工程里【一直没有时钟约束】，PnR 就不知道要按多少兆做建立时间检查，
#    于是"Timing analysis completed"其实什么也没验 —— 板子上跑得动是
#    运气好 + 27MHz 本来就不快。
#
#    ks_voice 的反馈环是整块板子最长的组合路径
#    （note 译码 -> 插值乘法 -> 阻尼滤波 -> 环增益 -> 写回），
#    必须先有一个明确的 27MHz 约束才能说它是安全的。
#
#  27MHz -> 周期 37.037ns，占空比 50% -> 半周期 18.518ns
#  ★ 每条约束必须写在一行里：这个解析器不认 "\" 续行（试过，报 TA2000）。
#=====================================================================
create_clock -name clk -period 37.037 -waveform {0 18.518} [get_ports {clk}]

report_timing -setup -from_clock [get_clocks {clk}] -to_clock [get_clocks {clk}] -max_paths 25 -max_common_paths 1
report_timing -hold -from_clock [get_clocks {clk}] -to_clock [get_clocks {clk}] -max_paths 25 -max_common_paths 1
