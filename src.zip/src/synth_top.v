//======================================================================
//  synth_top.v  --  Tang Nano 20K 实时音频合成引擎  v2.1
//
//  【里程碑 4】按键矩阵键盘 + 独立控制的自动演奏
//
//  声部编成（共 12 个发声模块）：
//    u_v0          = 自动演奏的旋律        ┐
//    u_v1/2/3      = 自动演奏的和弦三音     ┘ 【吉他】Karplus-Strong 拨弦
//      u_v4~u_v7     = 【键盘】波表声部（钢琴音色，外接音色键切到钢琴时出声）
//      u_ks0~u_ks3   = 【键盘】吉他声部（Karplus-Strong，切到吉他时出声）
//      键盘是 4x4 矩阵，最多 4 个键同时发声（赛题要求 ≥4 复音）。
//      ★ 两条音色通路【一直在跑】，音色键只负责选谁进混音器 —— 切换是瞬间的。
//
//  ★ 2026-09-29 起，自动演奏也换成吉他了（原来走波表）。
//    换掉 ADSR 包络不要紧 —— 拨弦的自然衰减【就是】包络；
//    每换一个音 = 门重新拉高 = 重新拨一次弦，正是吉他该有的行为。
//
//  两个板载按键（按下 = 高）：
//    S1 (pin 87) -> 自动演奏 开/关，一下切换。关掉后只剩键盘，方便单独弹
//    S2 (pin 88) -> 手动切歌：辞九门回忆 -> 江南 -> 青花瓷 -> 辞九门回忆
//    ★ 另外【一首放完会自动接下一首】，三首一直循环下去，不用手动切
//
//  键盘（4x4 矩阵，引脚见 synth.cst）：
//    【16 个键全是音符】，自然音阶，低音1 ~ 高音2（键 0~15）
//    键号 = 行*4 + 列，映射表见下面的 kbd_note()
//
//  ★★ 2026-10-02：操作方式（最终版）★★
//    键盘 16 个键【全部是音符】：低音1 ~ 高音2（键 0~15）。
//    音量、音色、升降八度都搬到板子外面的元件上了。
//
//  数字旋钮编码器（音量）—— 五脚模块，GND / S1 / S2 / KEY / 5V：
//    ★ 模块上标 5V 的那个脚【必须接 3V3】，接 5V 会打坏 IO（IO 是 3.3V）。
//    S1 (pin 30) / S2 (pin 31) -> 正交输出，转一格音量走两档，到头夹住
//    KEY (pin 77)              -> 短按 吉他<->钢琴；长按 1 秒 进出测试模式
//    ★ 2026-11-01 实测：76/80 接编码器完全不通（那是 SDIO_D2 等复用脚），
//      换到 30/31 立刻正常。76/80 已从代码和约束里删除，别再往回接。
//
//  升降八度键（两脚开关，一脚接引脚一脚接 GND，按下 = 低电平）：
//    btn_oct (pin 29) -> 低 / 中 / 高 三档循环，只作用于键盘
//
//  ★ 76/80/77 这三个脚原来是"音量+/音量-/音色"三个两脚开关用的，
//    现在让给编码器了。那三个开关可以拆掉。

//
//  键盘音色（外接按键切）：
//    吉他 = ks_voice.v 的拨弦声部（k0~k3）：起音"叮"一下，之后自然衰减，
//           松手 = 手按住弦止音。物理模型，不用调包络
//    钢琴 = voice.v 的波表声部（v4~v7）+ ADSR 包络
//    ★ 只切【键盘】—— 自动演奏那 4 路是 ks_voice，工程里没有对应的波表版本。
//    ★ 上电默认由常量 KBD_TIMBRE 决定（1 = 吉他）。
//
//  曲目表：每首 = 一张旋律表 + 一张和弦表。
//  加新曲子：① 写 mel_evt 的段 ② 写 chd_evt 的段
//            ③ 改 mel_base / mel_last / chd_base / chd_last
//
//  LED（共阳极，低电平亮）：
//    led[1:0]=曲目  led[2]=自动演奏开  led[4]=有键按着  led[5]=心跳
//    led[3]= 按音量键闪 0.1 秒 / 测试模式常亮 / 钢琴音色时常亮
//
//  ★ 测试模式（两个【音量键】同时按住 0.5 秒 进/出）：8 路纯正弦同时输出，
//    频率在 250Hz~2kHz 之间等比排开，给现场验证复音数用 ——
//    手机频谱 App 一照就是 8 根分得很开的尖峰。详见下面 test_mode 那一段。
//
//  音频通路：16×发声单元 -> 混音 -> 音量 -> I2S -> PCM5102A -> 外接音响
//            （测试模式时改走 8×test_osc 纯正弦，见下面的 test_mode 那一段）
//
//  ★★ 2026-11-01：输出设备从【板载 MAX98357A + 小喇叭】换成
//     【外接 PCM5102A（I2S 线路输出 DAC）+ 有源音响】★★
//
//     好消息是 I2S 那一层【一个字都不用改】，因为两边的协议是同一个：
//       · PCM5102A 认标准 Philips I2S（WS 比 MSB 提前 1 个 BCK），本项目就是
//       · 它要求 BCK/LRCK = 32/48/64，本项目正好是 64
//       · 16 位数据左对齐、后面补零到 32 位槽 —— 这正是它读 16 位的方式
//     真正要改的只有两件和协议无关的事：
//       ① PA_EN 的用途：原来拉高是【打开板载功放】，现在板载功放不用了，
//          拉低让它彻底关断（省电、不引入开关噪声）。见下面 "输出级" 那一段
//       ② 上电淡入：小喇叭听不出来的"咔"，经过功放+音箱会放大成一声闷响。
//          所以把音量做成 0 -> 目标值 的斜坡，见 vol_f 那一段
//
//     ⚠ 接线要点（板子上的跳线，不是代码）——不设对会没声或失真：
//        · SCK  → 接 GND（用它内部 PLL，FPGA 这边不用出 MCLK；
//                 27MHz 也除不出它要的 12.288MHz，走外部 MCLK 这条路是死的）
//        · FMT  → 接 GND（选 I2S。若跳成 LJ/RJ 会整体错位 1 位，声音发虚发破）
//        · XSMT → 接 3.3V（软静音，低有效。悬空/接地 = 静音，会以为没焊好）
//        · DEMP → GND，FLT → GND（默认即可）
//        · PCM5102 是【线路输出】，推不动喇叭，必须后面接有源音响/功放
//
//  采样率：46875 Hz（27MHz / 9 = 3MHz BCLK，64 BCLK / 帧）
//            PCM5102A 内部 PLL 认 8k~384k 的任意采样率，不需要凑 48k；
//            而 27MHz 也除不出 48000，硬凑就得重算全部音符表 —— 不值。
//======================================================================
module synth_top (
    input  wire       clk,        // 27MHz，pin 4
    input  wire       key1,       // 选音键，pin 87（板载，按下 = 高）
    input  wire       key2,       // 触发键，pin 88（板载，按下 = 高）
    output wire [3:0] kbd_row,    // 4x4 矩阵行，三态输出，pin 73/74/75/41
                                  //   ★ 第 4 行原来是 85，已弃用：
                                  //     85 = SDIO_D1，板上 10K 上拉，当行线时
                                  //     永远读高 -> 按一个键会响同列 4 个音。
                                  //     详见 synth.cst 里那段说明和 sim/tb_row3.v
    input  wire [3:0] kbd_col,    // 4x4 矩阵列，按下 = 高，pin 25/26/27/28
    output wire [5:0] led,        // pin 15~20，共阳极
    output wire       HP_BCK,     // pin 56  -> PCM5102A BCK
    output wire       HP_WS,      // pin 55  -> PCM5102A LRCK
    output wire       HP_DIN,     // pin 54  -> PCM5102A DIN
    output wire       PA_EN,      // pin 51  板载 MAX98357A 的 SD_MODE（低 = 关断）
    // ---- 三个外接按键（两脚轻触开关：一脚接引脚，一脚接 GND）----
    //   ★ 接法是【按下 = 低电平】（另一个脚接 GND），所以
    //     cst 里要 PULL_MODE=UP，代码里要取反 —— 和板载那两个键正好相反
    //     （板载 key1/key2 是 PULL_MODE=DOWN、按下 = 高）。
    //  ★★ 2026-10-02：btn_up / btn_dn / btn_tb 三个端口【已删除】★★
    //    用户把音量搬到旋钮编码器、音色搬到旋钮的 KEY 上，76/80/77 这几个脚
    //    【让给了编码器】。端口留着会占引脚、和编码器冲突
    //    （综合直接报 PR2030 "The constrained location has already been used"）。
    input  wire       btn_oct,    // 升降八度  pin 29
    // ---- 数字旋钮编码器（正交输出，控制音量）----
    //   ★ 模块上标着 5V 的那个脚【必须接 3V3】，不能接 5V —— IO 是 3.3V，会打坏。
    //     机械编码器是纯触点 + 上拉，3.3V 完全够用，输出也正好是 3.3V 电平。
    //   ★★ 2026-11-01 上板实测：76/80 不通，30/31 正常 ⇒ 只保留 30/31 ★★
    //     76/80 弃用（端口和引脚约束都已删除，别再往回接）：
    //       80 = IOT27A 就是 SDIO_D2，直连板载 microSD 卡座、带 10K 上拉，
    //            不插卡时这根线仍被板载器件拽住；
    //       76 = IOT30B 同样是被板载功能复用的脚。
    //     30/31（IOB14B / IOB29A）是引脚图上没有第二功能的纯空闲 IO。
    //     ★ 那两根旧线一定要【拔掉】，别留悬空飞线（飞线会捡噪声）。
    input  wire       enc_s1,     // pin 30  (IOB14B)
    input  wire       enc_s2,     // pin 31  (IOB29A)
    input  wire       enc_key,    // pin 77  旋钮按下（短按=切音色，长按1秒=测试模式）
    // OLED 显示屏（SSD1306, I2C）
    //   ★ 声明成 inout：I2C 是开漏总线，FPGA 只能"拉低"或"释放"，
    //     所以同一根线既当输出也当输入（要读从机的 ACK 和总线上其他位的电平）。
    inout  wire       oled_scl,   // pin 71
    inout  wire       oled_sda    // pin 72
);

    //==================================================================
    //                      音符编码
    //   note[5:0] = {八度[1:0], 半音[3:0]}
    //     八度：0 = C3 区  1 = C4 区  2 = C5 区  3 = C6 区
    //     半音：0=C 1=C# 2=D 3=D# 4=E 5=F 6=F# 7=G 8=G# 9=A 10=A# 11=B
    //   六位全 1 = 休止符
    //
    //   频率 = 半音表[半音] << 八度
    //   因为每高一个八度频率翻倍，正好是一次左移，所以只需要一张
    //   12 个半音的小表就能覆盖全部音域。
    //==================================================================
    localparam [5:0] N_REST = 6'b111111;

    //  ★★ 编码器故障定位开关 ★★（2026-11-01 重写，仅排线时临时改成 1）
    //    1 = 定位模式：
    //          · 歌声/和弦全关，只听旋钮 —— 免得音乐盖住判断
    //          · 碰一下 30(S1) 响低音1，碰一下 31(S2) 响高音1（差两个八度，不会听混）
    //          · 6 个 LED 变成"看 S1/S2 到底有没有动"的电平表，
    //            逐位说明见文件末尾【编码器故障定位】那一段
    //    0 = 正常工作（现在旋钮已经通了，保持 0）。
    //
    //  ★ 它必须声明在这里：后面的 mel_gate/chd_gate 要用它，
    //    写在使用处附近会变成"用在前、声明在后"——iverilog 会报，
    //    而高云综合器会静默把它当成一根 1 位线网。
    localparam ENC_DIAG = 1'b0;

    // ---- 低音区（和弦用，C3 八度）----
    localparam [5:0] N_C3 = 6'b00_0000;
    localparam [5:0] N_E3 = 6'b00_0100;
    localparam [5:0] N_F3 = 6'b00_0101;
    localparam [5:0] N_G3 = 6'b00_0111;
    localparam [5:0] N_A3 = 6'b00_1001;
    localparam [5:0] N_B3 = 6'b00_1011;
    localparam [5:0] N_C4 = 6'b01_0000;
    localparam [5:0] N_D4 = 6'b01_0010;

    // ---- 高音区（旋律用，C5 八度）----
    localparam [5:0] N_C5 = 6'b10_0000;
    localparam [5:0] N_D5 = 6'b10_0010;
    localparam [5:0] N_E5 = 6'b10_0100;
    localparam [5:0] N_F5 = 6'b10_0101;
    localparam [5:0] N_G5 = 6'b10_0111;
    localparam [5:0] N_A5 = 6'b10_1001;
    localparam [5:0] N_B5 = 6'b10_1011;
    localparam [5:0] N_C6 = 6'b11_0000;

    // ---- 半音频率控制字表（C3 八度）----
    // phase_inc = f × 2^32 / 46875
    function [31:0] semi_inc;
        input [3:0] s;
        begin
            case (s)
                4'd0 : semi_inc = 32'd11985850;   // C   130.8128 Hz
                4'd1 : semi_inc = 32'd12698562;   // C#  138.5913 Hz
                4'd2 : semi_inc = 32'd13453661;   // D   146.8324 Hz
                4'd3 : semi_inc = 32'd14253656;   // D#  155.5635 Hz
                4'd4 : semi_inc = 32'd15101224;   // E   164.8138 Hz
                4'd5 : semi_inc = 32'd15999186;   // F   174.6141 Hz
                4'd6 : semi_inc = 32'd16950548;   // F#  184.9972 Hz
                4'd7 : semi_inc = 32'd17958479;   // G   195.9977 Hz
                4'd8 : semi_inc = 32'd19026343;   // G#  207.6523 Hz
                4'd9 : semi_inc = 32'd20157713;   // A   220.0000 Hz
                4'd10: semi_inc = 32'd21356355;   // A#  233.0819 Hz
                4'd11: semi_inc = 32'd22626273;   // B   246.9417 Hz
                default: semi_inc = 32'd11985850;
            endcase
        end
    endfunction

    // ---- 音符号 -> 频率控制字（半音表左移八度）----
    function [31:0] note_pinc;
        input [5:0] n;
        begin
            note_pinc = semi_inc(n[3:0]) << n[5:4];
        end
    endfunction

    // ---- 和弦整体升降八度 ----
    // note 编码里"八度"占高 2 位、半音占低 4 位，所以 +16 才是升高一个八度
    //   （+4 只等于升高 4 个半音，别搞混）
    //     0  = 停在 C3 区（130~196Hz）—— 小喇叭放不出这么低，听着会很小声
    //    16  = 升到 C4 区（262~392Hz）—— 小喇叭能正常重放，推荐
    localparam [5:0] CHD_OCT_UP = 6'd16;

    // ---- 和弦取音：ch 是上面的和弦编号，idx=0(根音) 1(三音) 2(五音) ----
    function [5:0] chord_note;
        input [3:0] ch;
        input [1:0] idx;
        reg [5:0] n0, n1, n2;
        begin
            case (ch)
                4'd0 : begin n0 = 6'd8;  n1 = 6'd16; n2 = 6'd19; end   // ★ bA (I)  辞九门回忆用
                4'd1 : begin n0 = 6'd17; n1 = 6'd21; n2 = 6'd24; end   // ★ bD (IV) 辞九门回忆用
                4'd2 : begin n0 = 6'd19; n1 = 6'd23; n2 = 6'd26; end   // ★ bE (V)  辞九门回忆用
                //  ★ 0/1/2 原来是"小星星"的 C/F/G。小星星被辞九门回忆替换掉之后
                //    这三个槽位空出来了 —— 和弦编号只有 4 位（0~15），很紧张：
                //    江南 3/4/5/12，青花瓷 6~11，15 给辞九门回忆的 Fm。
                4'd3 : begin n0 = 6'd10; n1 = 6'd18; n2 = 6'd21; end   // ★ bB (I)  江南用
                4'd4 : begin n0 = 6'd19; n1 = 6'd23; n2 = 6'd26; end   // ★ bE (IV) 江南用
                4'd5 : begin n0 = 6'd21; n1 = 6'd25; n2 = 6'd32; end   // ★ F  (V)  江南用
                //  ★ 3/4/5 原来是 Em/Am/Dm，三首老歌都没用到，江南要用 bB 大调的和弦，
                //    就把这三个槽位改成了 bB/bE/F。和弦编号只有 4 位（0~15）：
                //    0~2 归小星星、6~11 归青花瓷，剩下的能用的就是 3/4/5/12/13/14。
                4'd6 : begin n0 = 6'd18; n1 = 6'd22; n2 = 6'd25; end   // D
                4'd7 : begin n0 = 6'd20; n1 = 6'd24; n2 = 6'd27; end   // E
                4'd8 : begin n0 = 6'd17; n1 = 6'd20; n2 = 6'd24; end   // C#m
                4'd9 : begin n0 = 6'd22; n1 = 6'd25; n2 = 6'd33; end   // F#m
                4'd10: begin n0 = 6'd11; n1 = 6'd18; n2 = 6'd22; end   // Bm
                4'd11: begin n0 = 6'd9; n1 = 6'd17; n2 = 6'd20; end   // A
                4'd12: begin n0 = 6'd23; n1 = 6'd26; n2 = 6'd34; end  // ★ Gm (vi)  江南用
                4'd13: begin n0 = 6'd16; n1 = 6'd19; n2 = 6'd23; end  // ★ Cm (ii)  江南备用
                4'd14: begin n0 = 6'd18; n1 = 6'd21; n2 = 6'd25; end  // ★ Dm (iii) 江南备用
                4'd15: begin n0 = 6'd21; n1 = 6'd24; n2 = 6'd32; end  // ★ Fm (vi)  辞九门回忆用
                default: begin n0 = 6'd16; n1 = 6'd20; n2 = 6'd23; end
            endcase
            case (idx)
                2'd0:    chord_note = n0;
                2'd1:    chord_note = n1;
                default: chord_note = n2;
            endcase
        end
    endfunction

    // ---- 青花瓷专用：同理但整首降 8 个半音（保持和旋律同一调性）----
    function [5:0] chord_note_qh;
        input [3:0] ch;
        input [1:0] idx;
        reg [5:0] n0, n1, n2;
        begin
            case (ch)
                4'd6 : begin n0 = 6'd6;  n1 = 6'd10; n2 = 6'd17; end  // D   -> F#3 A#3 C#4
                4'd7 : begin n0 = 6'd8;  n1 = 6'd16; n2 = 6'd19; end  // E   -> G#3 C4  D#4
                4'd8 : begin n0 = 6'd5;  n1 = 6'd8;  n2 = 6'd16; end  // C#m -> F3  G#3 C4
                4'd9 : begin n0 = 6'd10; n1 = 6'd17; n2 = 6'd21; end  // F#m -> A#3 C#4 F4
                4'd10: begin n0 = 6'd3; n1 = 6'd6; n2 = 6'd10; end   // Bm  -> D#3 F#3 A#3
                4'd11: begin n0 = 6'd1; n1 = 6'd5; n2 = 6'd8; end    // A   -> C#3 F3  G#3
                // 上面 6 个就是青花瓷实际用到的全部和弦编号（chd_evt 里 64..80 段）。
                // ★ 曾经只写了 10 和 11 两个，其余掉进 default，导致 17 段里有 10 段
                //   全都弹成同一个 C 大三和弦（D/E/C#m/F#m 全丢）。耳朵听不出来，
                //   是"扫源码 + 比对覆盖"抓出来的。
                // 下面这个 default 只是防呆，正常永远走不到。
                default: begin n0 = 6'd16; n1 = 6'd20; n2 = 6'd23; end
            endcase
            case (idx)
                2'd0:    chord_note_qh = n0;
                2'd1:    chord_note_qh = n1;
                default: chord_note_qh = n2;
            endcase
        end
    endfunction

    //==================================================================
    //   曲目选择相关寄存器（★ 必须声明在"调音参数区"之前 ★）
    //   因为参数区里的 song_unit(song) / mel_base(song) 会引用 song，
    //   Verilog 不允许"用在前、声明在后" —— 高云综合器会容忍，
    //   但那会隐式推断出 1 位线网（只能表示 2 首歌），是隐蔽的错。
    //   iverilog 严格按标准报错才把这个坑揪出来。
    //==================================================================
    // ---- 曲目选择 与 自动演奏开关 ----
    //  ★ song 从 2 位加宽到 3 位 = 最多 8 首（原来 2 位只能 4 首）。
    //    ★★ 但只有前 SONG_CNT 首【填了谱子】，切歌不会跨过这个数（见下面 song_inc）。
    reg [2:0] song;     // 0=辞九门回忆 1=江南 2=青花瓷（3~7 空的，见 SONG_CNT）
    reg auto_on;        // 自动演奏总开关，S1 一下切换。上电默认开
    reg song_rst;       // 切歌请求，延迟一拍执行

    //==================================================================
    //   ★★★ 调音参数区：想改音色 / 节奏，只改这一块就够了 ★★★
    //==================================================================
    localparam [24:0] BEAT_CYCLES = 25'd10800000;   // 一拍 = 0.4s @27MHz

    // ADSR 包络（数字越大 = 该阶段越慢）
    localparam signed [15:0] ENV_SUS = 16'sd22937;  // 延音电平 = 0.70 × 32767
    localparam [9:0] A_DIV = 10'd4;                 // 起音 -> 约  4.9ms
                                                    // （从 8 调小到 4：让"到满幅"的总延迟
                                                    //   压到 10ms 以内，堵住答辩时的口径争议）
    localparam [9:0] D_DIV = 10'd412;               // 衰减 -> 约 150.0ms
    localparam [9:0] R_DIV = 10'd141;               // 收音 -> 约 119.8ms

    // 每首歌"一个 16 分音符"的时钟数 —— 这就是每首歌的速度
    //   小星星：一拍 0.4s -> 16 分 = 0.1s = 2700000 周期；江南：♩=72 -> 5625000
    //   青花瓷：      ♩=54       ->  16 分 = 0.2778s = 7500000 周期
    function [23:0] song_unit;
        input [2:0] sng;
        begin
            case (sng)
                // 辞九门回忆：♩=66
                //   ★ 这一项 = 【一个十六分音符】占多少个 27MHz 时钟。
                //     27e6 x 60 / (BPM x 4) = 4.05e8 / BPM，所以：
                //       ♩=54 -> 7500000   ♩=60 -> 6750000
                //       ♩=66 -> 6136364   ♩=72 -> 5625000
                //     用户先说 54 太慢，调到 66。嫌快就往上加这个数，嫌慢就往下减。
                3'd0:    song_unit = 24'd6136364;   // 辞九门回忆 ♩=66
                // 江南：♩=54（一拍 1.111s -> 16分 = 0.2778s）
                //   ★ 速度调过两轮：先 ♩=72（用户说"像倍速播放"），
                //     再 ♩=36（用户说"太拖沓"），最后定在中间的 54。
                //     54 正好和青花瓷一样，两首抒情歌速度就统一了。
                //   ★ 觉得还不对就改这一个数：它是【十六分音符多少拍】，
                //     数值翻倍 = 速度减半。
                3'd1:    song_unit = 24'd7500000;   // 江南 ♩=54
                default: song_unit = 24'd7500000;   // 青花瓷 ♩=54
            endcase
        end
    endfunction

    // 每首歌在合并表里的起始下标
    function [9:0] mel_base;
        input [2:0] sng;
        begin
            case (sng)
                3'd0:    mel_base = 9'd0;           // 小星星
                3'd1:    mel_base = 9'd192;         // 江南（90 条 -> 192..281）
                default: mel_base = 9'd96;          // 青花瓷
            endcase
        end
    endfunction
    function [9:0] mel_last;
        input [2:0] sng;
        begin
            case (sng)
                3'd0:    mel_last = 8'd53;          // 辞九门回忆 54 个事件
                3'd1:    mel_last = 8'd89;          // 江南 90 个事件
                default: mel_last = 8'd95;          // 青花瓷 96 个事件
            endcase
        end
    endfunction
    function [8:0] chd_base;
        input [2:0] sng;
        begin
            case (sng)
                3'd0:    chd_base = 8'd0;
                3'd1:    chd_base = 8'd32;
                default: chd_base = 8'd64;          // 青花瓷
            endcase
        end
    endfunction
    function [8:0] chd_last;
        input [2:0] sng;
        begin
            case (sng)
                3'd0:    chd_last = 7'd7;           // 辞九门回忆 8 段
                3'd1:    chd_last = 7'd12;          // 江南 13 段
                default: chd_last = 7'd16;          // 青花瓷 17 段
            endcase
        end
    endfunction

    wire [23:0] UNIT_CYC = song_unit(song);
    // 收音从"延音电平"降到 0 需要 R_DIV × ENV_SUS 个时钟，再留 0.15ms 余量
    //
    // ★★ 2026-11-02 15:0x：120ms -> 50ms ★★
    //   这个常量决定【门提前多久落下】。原来是 141×22937+4096 ≈ 120ms，
    //   而 ♩=66 的十六分音符只有 227ms —— 门只保 107ms 就落，
    //   剩下的 120ms 全交给收音，钢琴声部因此每个音都被切成一小段，
    //   听感就是"嘀、嘀、嘀"像电报。
    //   缩到 50ms 后音符能响 177ms（占时值的 78%），余音才连得起来。
    //   ★ 必须远小于最短时值（227ms），否则 mel_rel_at 会被兜到 0，
    //     门从头到尾都是低的，短音符会变成【完全不发声】。
    localparam [24:0] RELEASE_CYC = 25'd1350000;   // 50ms @27MHz

    // 分层音量。★ 这里就是全场唯一的"音量旋钮"，别处调不了 ★
    //   每 -1 位 = 音量翻倍 = 信噪比 +6dB；每 +1 位 = 减半 = 信噪比 -6dB。
    //   压到 -30dBFS 以下量化噪声会明显听到（信号小，固定的 1-LSB 截断误差占比就大）。
    //   旋律 1 路 32767>>MEL_SHIFT，和弦 3 路合计 ≈1050，键盘 4 路合计 8188
    //   最大 ≈10300 < 32767，余量 10dB，不会削顶。
    //   ★ 具体数字看 check_rtl.py 的 [C] 段（它是从 RTL 里读常量算的，不会过期）。
    //   （吉他那档原始峰值比波表低（端到端实测 0.0205 vs 0.062），KS_SHIFT 比
    //    钢琴比拨弦多移 2 位才把峰值拉平 —— 见下面 kbd_lvl 的说明。
    //     加旋律+和弦 18461 < 32767，余量 5dB，仍然不会削顶。）
    //   注：键盘上 A/C 两个音听感偏脏 —— 已查明是板载小喇叭，不是代码。
    localparam integer MEL_SHIFT = 4;   // 旋律（2026-09-29 换吉他后 5->4，见混音层注释）
    //  ★ KBD_SHIFT 【已经不用了】—— 音色变成运行时可切之后，钢琴那边的移位
    //    必须相对 KS_SHIFT 差一个固定值（见下面 kbd_lvl），写成两个独立常量
    //    会在切换音色时电平不对。留着只是怕别处还有引用。
    localparam integer KBD_SHIFT = 4;   // 【已废弃】键盘钢琴声部原用的移位
    localparam integer KS_SHIFT  = 3;   // 键盘 4 路（k0~k3，吉他/拨弦）

    //==================================================================
    //                        复位 / 采样节拍
    //==================================================================
    reg [15:0] por_cnt = 16'd0;
    reg        rst_n   = 1'b0;

    always @(posedge clk) begin
        if (por_cnt == 16'hFFFF) begin
            rst_n <= 1'b1;
        end else begin
            por_cnt <= por_cnt + 1'b1;
            rst_n   <= 1'b0;
        end
    end

    wire               fs_tick;
    wire signed [15:0] mix_out;

    //==================================================================
    //                        按键消抖 + 边沿
    //==================================================================
    localparam [14:0] DB_CYCLES = 15'd26999;        // 1ms

    reg [14:0] db_cnt;
    reg [3:0]  db_sh1, db_sh2, db_sh5, db_sh6;

    wire key1_in = key1;        // 板载按键：按下 = 高电平，不用取反
    wire key2_in = key2;
    // 外接按键：两脚开关另一头接 GND，按下 = 低电平，取反
    //  ★ btn_up/btn_dn 已删（音量搬到旋钮），这两条输入也就不需要了
    //  ★ 2026-10-02：音色切换（含长按进测试模式）从两脚开关 btn_tb(77) 搬到
    //    旋钮的 KEY 脚上 —— 用户说这样能少用一个两脚开关。
    //    ★ 只换【输入源】，后面的消抖、边沿、长短按判定全不用动。
    //    ★ btn_tb 的端口留着（线可能还接着），但已经不再驱动任何东西。
    wire btn_tb_in = ~enc_key;
    wire btn_oct_in = ~btn_oct;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            db_cnt <= 15'd0;
            db_sh1 <= 4'd0;
            db_sh2 <= 4'd0;
            db_sh5 <= 4'd0;
            db_sh6 <= 4'd0;
        end else if (db_cnt == DB_CYCLES) begin
            db_cnt <= 15'd0;
            db_sh1 <= {db_sh1[2:0], key1_in};
            db_sh2 <= {db_sh2[2:0], key2_in};
            db_sh5 <= {db_sh5[2:0], btn_tb_in};
            db_sh6 <= {db_sh6[2:0], btn_oct_in};
        end else begin
            db_cnt <= db_cnt + 15'd1;
        end
    end

    wire key1_db = &db_sh1;
    wire key2_db = &db_sh2;
    wire btn_tb_db = &db_sh5;
    wire btn_oct_db = &db_sh6;

    reg key1_d, key2_d, btb_d, boct_d;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            key1_d <= 1'b0;
            key2_d <= 1'b0;
            btb_d  <= 1'b0;
            boct_d <= 1'b0;
        end else begin
            key1_d <= key1_db;
            key2_d <= key2_db;
            btb_d  <= btn_tb_db;
            boct_d <= btn_oct_db;
        end
    end

    wire key1_press = key1_db & ~key1_d;
    wire key2_press = key2_db & ~key2_d;

    wire btn_oct_press = btn_oct_db & ~boct_d;

    //==================================================================
    //  旋钮编码器 -> 音量（2026-11-01 定型：只用 30/31 这一对）
    //==================================================================
    //  ---- ★ 引脚选定过程（别再往 76/80 上接）★ ----
    //  最初接 76/80 转旋钮完全不动，改接 30/31 立刻正常。
    //  基本可以确定的差别：80 = IOT27A 就是 SDIO_D2，直接连在板载
    //  microSD 卡座上（带 10K 上拉到 3V3），不插卡时那根线仍然被板载
    //  器件拽着；76 = IOT30B 同样属于被板载功能复用的脚。
    //  ⇒ 30/31（IOB14B / IOB29A）是引脚图上没有第二功能的纯空闲 IO，
    //    现在专供编码器，别的一概不占。
    //
    //  ---- 解码逻辑为什么这么写 ----
    //  这段踩过两次坑，都是"怎么处理跳变"的问题：
    //    ① 早期版本每 2ms 才采样一次、斜对角跳变直接丢弃 ——
    //       人手拧一下，2ms 里常常已经走过两个状态（采到 11->00），
    //       整段转动一个数都加不上，现象是"越转越没反应"。
    //    ② 后来为了省事把两对引脚【硬与】（enc_s1 & enc_s1b），
    //       只要空着那对里有一根读到低，整路被永久拉死，而且只死一路；
    //       剩下那一路在 11<->01 之间来回，一正一反互相抵消，
    //       表现就是"灯条会亮、音量一格都不走"。这就是实测那个现象。
    //  ⇒ 现在的做法固化在 enc_dec 里：每路独立消抖 500us、相邻状态查表
    //    判方向、斜对角按上次方向继续（不丢）、累加器围绕中点摆动。
    //    只剩一路时的形态是【净步数为 0】—— tb_enc_dec.v 里专门留了
    //    这条用例守住它，以后改这段先跑那个测试台。
    //
    //  ★ 模块定义在【本文件末尾】，不是单独的 .v 文件。原因见那边注释
    //    （高云 IDE 综合读的 synth.prj 不随 .gprj 自动更新，新增源文件
    //     会报 EX3937 unknown module —— 2026-11-01 已经踩过一次）。
    //==================================================================
    wire enc_s1_lev, enc_s2_lev;
    wire enc_up, enc_dn, enc_act;

    enc_dec u_enc (
        .clk      (clk),
        .rst_n    (rst_n),
        .s1_raw   (enc_s1),          // pin 30  (IOB14B)
        .s2_raw   (enc_s2),          // pin 31  (IOB29A)
        .step_up  (enc_up),          // 走一格：单拍脉冲
        .step_dn  (enc_dn),
        .act      (enc_act),         // 动一下（单拍）—— 只点亮音量条
        .s1_level (enc_s1_lev),      // 消抖后的电平（诊断用）
        .s2_level (enc_s2_lev),
        .s1_hot   (),                // 通道活动指示：排查 76/80 时用过，
        .s2_hot   ()                 // 旋钮已通，暂时不接（综合器会优化掉）
    );

    wire [1:0] enc_now = {enc_s1_lev, enc_s2_lev};

    //==================================================================
    //  旋钮 KEY【长按 1 秒】= 进出测试模式
    //==================================================================
    //  ★ 原来这个手势是"两个音量键同时按住半秒"。用户把音量搬到旋钮上、
    //    那两个键腾出来了，手势也就没了 —— 但测试模式是赛题现场验证要用的，
    //    必须有入口，所以挪到音色键的长按：短按 = 切音色，长按 = 测试模式。
    localparam [26:0] LONG_HOLD = 27'd27000000;     // 1 秒 @27MHz

    reg [26:0] tb_hold;
    reg        tb_long_fired;       // 触发过就不再重复，直到松手
    reg        tb_fired_d;

    //  ★ 音色键的动作认【松手】而不是【按下】，而且长按不算 —— 所以这条 wire
    //    必须写在 tb_long_fired【之后】。写成按下沿的话，长按进测试模式的同时
    //    会把音色也切掉，用户没想要这个。
    //    ★ 第一次写就踩了"用在前、声明在后"：iverilog 直接报
    //      `Unable to bind wire/reg/memory 'tb_long_fired'`，
    //      而高云综合器会【静默】把它当成一根 1 位线网。改完先跑 iverilog。
    wire btn_tb_press = ~btn_tb_db & btb_d & ~tb_long_fired;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            tb_hold       <= 27'd0;
            tb_long_fired <= 1'b0;
            tb_fired_d    <= 1'b0;
        end else begin
            tb_fired_d <= tb_long_fired;
            if (!btn_tb_db) begin
                tb_hold       <= 27'd0;
                tb_long_fired <= 1'b0;
            end else if (!tb_long_fired) begin
                tb_hold <= tb_hold + 27'd1;
                if (tb_hold >= LONG_HOLD) tb_long_fired <= 1'b1;
            end
        end
    end

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            auto_on  <= 1'b1;       // 上电默认放小星星（"一插上就响"）
        end else begin
            // S1：自动演奏 开/关。一下切换。
            //  ★ 2026-11-01 修：之前这里被改成了恒为 1（S1 去触发扫音阶了），
            //    结果 S1 关不掉自动演奏 —— 用户按 S1 只听到歌声停 8 秒又自己回来。
            //    现在恢复：按下切一次。
            if (key1_press) auto_on <= ~auto_on;
        end
    end

    // ★ song / song_rst 的时序块【挪到旋律逻辑后面】了（原来在这里）。
    //   因为"一首放完自动接下一首"要用到 mel_done / mel_last，
    //   而它们在下面才声明 —— 这个项目栽过"用在前、声明在后"，
    //   高云综合器会容忍并静默推断成 1 位线网，只有 iverilog 会报。

    //==================================================================
    //                   旋律：事件表（42 个音 = 48 拍）
    //   事件 = {时长[1:0], 音高[5:0]}，时长单位是拍（1=四分 2=二分）
    //==================================================================
    // 两张旋律表合并成一张：索引最高位选曲目
    //   i[6]=0 -> 辞九门回忆(0..53)  i[6]=1 -> 江南(192..281)  i[6]=2 -> 青花瓷(96..191)
    // 用"单函数 + 变量下标"而不是"两函数 + mux"：后者会让 GowinSynthesis
    // 误报组合环(AG0100/AG0101)。
    function [9:0] mel_evt;
        input [9:0] i;
        begin
            case (i)
                // ---- 辞九门回忆（替换掉了原来的小星星）----
                // ---- 《辞九门回忆》（由 sim/jianpu2rtl.py 从数字简谱生成，别手改）----
                9'd0   : mel_evt = {4'd2 , 6'd24}; 9'd1   : mel_evt = {4'd1 , 6'd26}; 9'd2   : mel_evt = {4'd1 , 6'd24}; 9'd3   : mel_evt = {4'd2 , 6'd21};
                9'd4   : mel_evt = {4'd1 , 6'd32}; 9'd5   : mel_evt = {4'd5 , 6'd26}; 9'd6   : mel_evt = {4'd2 , 6'd24}; 9'd7   : mel_evt = {4'd2 , 6'd21};
                9'd8   : mel_evt = {4'd2 , 6'd32}; 9'd9   : mel_evt = {4'd2 , 6'd26}; 9'd10  : mel_evt = {4'd2 , 6'd32}; 9'd11  : mel_evt = {4'd1 , 6'd35};
                9'd12  : mel_evt = {4'd5 , 6'd32}; 9'd13  : mel_evt = {4'd2 , 6'd26}; 9'd14  : mel_evt = {4'd2 , 6'd24}; 9'd15  : mel_evt = {4'd2 , 6'd21};
                9'd16  : mel_evt = {4'd2 , 6'd24}; 9'd17  : mel_evt = {4'd2 , 6'd26}; 9'd18  : mel_evt = {4'd1 , 6'd32}; 9'd19  : mel_evt = {4'd5 , 6'd26};
                9'd20  : mel_evt = {4'd2 , 6'd24}; 9'd21  : mel_evt = {4'd2 , 6'd26}; 9'd22  : mel_evt = {4'd3 , 6'd32}; 9'd23  : mel_evt = {4'd1 , 6'd26};
                9'd24  : mel_evt = {4'd2 , 6'd32}; 9'd25  : mel_evt = {4'd1 , 6'd35}; 9'd26  : mel_evt = {4'd5 , 6'd32}; 9'd27  : mel_evt = {4'd2 , 6'd26};
                9'd28  : mel_evt = {4'd2 , 6'd24}; 9'd29  : mel_evt = {4'd2 , 6'd21}; 9'd30  : mel_evt = {4'd2 , 6'd24}; 9'd31  : mel_evt = {4'd2 , 6'd26};
                9'd32  : mel_evt = {4'd1 , 6'd32}; 9'd33  : mel_evt = {4'd5 , 6'd26}; 9'd34  : mel_evt = {4'd2 , 6'd24}; 9'd35  : mel_evt = {4'd2 , 6'd26};
                9'd36  : mel_evt = {4'd3 , 6'd32}; 9'd37  : mel_evt = {4'd1 , 6'd26}; 9'd38  : mel_evt = {4'd2 , 6'd32}; 9'd39  : mel_evt = {4'd1 , 6'd35};
                9'd40  : mel_evt = {4'd5 , 6'd32}; 9'd41  : mel_evt = {4'd2 , 6'd26}; 9'd42  : mel_evt = {4'd2 , 6'd32}; 9'd43  : mel_evt = {4'd2 , 6'd35};
                9'd44  : mel_evt = {4'd2 , 6'd32}; 9'd45  : mel_evt = {4'd2 , 6'd26}; 9'd46  : mel_evt = {4'd2 , 6'd32}; 9'd47  : mel_evt = {4'd4 , 6'd26};
                9'd48  : mel_evt = {4'd2 , 6'd24}; 9'd49  : mel_evt = {4'd1 , 6'd26}; 9'd50  : mel_evt = {4'd3 , 6'd24}; 9'd51  : mel_evt = {4'd1 , 6'd26};
                9'd52  : mel_evt = {4'd1 , 6'd24}; 9'd53  : mel_evt = {4'd12, 6'd21};
                // ---- 江南副歌 ----
                // ---- 《江南》（由 sim/jianpu2rtl.py 从数字简谱生成，别手改）----
                9'd192 : mel_evt = {4'd4 , 6'd37}; 9'd193 : mel_evt = {4'd2 , 6'd63}; 9'd194 : mel_evt = {4'd1 , 6'd26}; 9'd195 : mel_evt = {4'd1 , 6'd32};
                9'd196 : mel_evt = {4'd1 , 6'd34}; 9'd197 : mel_evt = {4'd1 , 6'd35}; 9'd198 : mel_evt = {4'd1 , 6'd34}; 9'd199 : mel_evt = {4'd1 , 6'd35};
                9'd200 : mel_evt = {4'd1 , 6'd37}; 9'd201 : mel_evt = {4'd1 , 6'd35}; 9'd202 : mel_evt = {4'd2 , 6'd34}; 9'd203 : mel_evt = {4'd1 , 6'd26};
                9'd204 : mel_evt = {4'd4 , 6'd32}; 9'd205 : mel_evt = {4'd1 , 6'd35}; 9'd206 : mel_evt = {4'd1 , 6'd34}; 9'd207 : mel_evt = {4'd1 , 6'd32};
                9'd208 : mel_evt = {4'd1 , 6'd26}; 9'd209 : mel_evt = {4'd1 , 6'd25}; 9'd210 : mel_evt = {4'd1 , 6'd26}; 9'd211 : mel_evt = {4'd1 , 6'd32};
                9'd212 : mel_evt = {4'd1 , 6'd34}; 9'd213 : mel_evt = {4'd1 , 6'd32}; 9'd214 : mel_evt = {4'd1 , 6'd26}; 9'd215 : mel_evt = {4'd2 , 6'd32};
                9'd216 : mel_evt = {4'd3 , 6'd41}; 9'd217 : mel_evt = {4'd2 , 6'd63}; 9'd218 : mel_evt = {4'd1 , 6'd25}; 9'd219 : mel_evt = {4'd1 , 6'd21};
                9'd220 : mel_evt = {4'd4 , 6'd23}; 9'd221 : mel_evt = {4'd2 , 6'd63}; 9'd222 : mel_evt = {4'd4 , 6'd26}; 9'd223 : mel_evt = {4'd2 , 6'd37};
                9'd224 : mel_evt = {4'd3 , 6'd63}; 9'd225 : mel_evt = {4'd1 , 6'd26}; 9'd226 : mel_evt = {4'd1 , 6'd35}; 9'd227 : mel_evt = {4'd1 , 6'd34};
                9'd228 : mel_evt = {4'd1 , 6'd35}; 9'd229 : mel_evt = {4'd1 , 6'd34}; 9'd230 : mel_evt = {4'd1 , 6'd37}; 9'd231 : mel_evt = {4'd1 , 6'd35};
                9'd232 : mel_evt = {4'd2 , 6'd34}; 9'd233 : mel_evt = {4'd1 , 6'd26}; 9'd234 : mel_evt = {4'd5 , 6'd32}; 9'd235 : mel_evt = {4'd1 , 6'd26};
                9'd236 : mel_evt = {4'd1 , 6'd32}; 9'd237 : mel_evt = {4'd1 , 6'd34}; 9'd238 : mel_evt = {4'd1 , 6'd35}; 9'd239 : mel_evt = {4'd1 , 6'd34};
                9'd240 : mel_evt = {4'd1 , 6'd35}; 9'd241 : mel_evt = {4'd1 , 6'd37}; 9'd242 : mel_evt = {4'd1 , 6'd35}; 9'd243 : mel_evt = {4'd2 , 6'd34};
                9'd244 : mel_evt = {4'd1 , 6'd26}; 9'd245 : mel_evt = {4'd4 , 6'd32}; 9'd246 : mel_evt = {4'd1 , 6'd35}; 9'd247 : mel_evt = {4'd1 , 6'd34};
                9'd248 : mel_evt = {4'd1 , 6'd32}; 9'd249 : mel_evt = {4'd1 , 6'd26}; 9'd250 : mel_evt = {4'd1 , 6'd25}; 9'd251 : mel_evt = {4'd1 , 6'd26};
                9'd252 : mel_evt = {4'd1 , 6'd32}; 9'd253 : mel_evt = {4'd1 , 6'd34}; 9'd254 : mel_evt = {4'd1 , 6'd32}; 9'd255 : mel_evt = {4'd1 , 6'd26};
                9'd256 : mel_evt = {4'd2 , 6'd32}; 9'd257 : mel_evt = {4'd3 , 6'd41}; 9'd258 : mel_evt = {4'd1 , 6'd25}; 9'd259 : mel_evt = {4'd1 , 6'd26};
                9'd260 : mel_evt = {4'd1 , 6'd25}; 9'd261 : mel_evt = {4'd1 , 6'd37}; 9'd262 : mel_evt = {4'd4 , 6'd23}; 9'd263 : mel_evt = {4'd2 , 6'd63};
                9'd264 : mel_evt = {4'd4 , 6'd26}; 9'd265 : mel_evt = {4'd2 , 6'd37}; 9'd266 : mel_evt = {4'd3 , 6'd63}; 9'd267 : mel_evt = {4'd1 , 6'd26};
                9'd268 : mel_evt = {4'd1 , 6'd35}; 9'd269 : mel_evt = {4'd1 , 6'd34}; 9'd270 : mel_evt = {4'd1 , 6'd35}; 9'd271 : mel_evt = {4'd1 , 6'd34};
                9'd272 : mel_evt = {4'd1 , 6'd37}; 9'd273 : mel_evt = {4'd1 , 6'd35}; 9'd274 : mel_evt = {4'd2 , 6'd34}; 9'd275 : mel_evt = {4'd1 , 6'd26};
                9'd276 : mel_evt = {4'd3 , 6'd32}; 9'd277 : mel_evt = {4'd1 , 6'd35}; 9'd278 : mel_evt = {4'd1 , 6'd34}; 9'd279 : mel_evt = {4'd5 , 6'd32};
                9'd280 : mel_evt = {4'd9 , 6'd26}; 9'd281 : mel_evt = {4'd4 , 6'd63};
                // ---- 青花瓷副歌（1=A，用户手写谱，96 个事件）----
                9'd96 : mel_evt = {4'd1, 6'b111111};
                9'd97 : mel_evt = {4'd1, 6'd40};   // E6
                9'd98 : mel_evt = {4'd1, 6'd40};   // E6
                9'd99 : mel_evt = {4'd1, 6'd37};   // C#6
                9'd100: mel_evt = {4'd1, 6'd35};   // B5
                9'd101: mel_evt = {4'd1, 6'd37};   // C#6
                9'd102: mel_evt = {4'd2, 6'd26};   // F#5
                9'd103: mel_evt = {4'd1, 6'd35};   // B5
                9'd104: mel_evt = {4'd1, 6'd37};   // C#6
                9'd105: mel_evt = {4'd1, 6'd40};   // E6
                9'd106: mel_evt = {4'd1, 6'd37};   // C#6
                9'd107: mel_evt = {4'd4, 6'd35};   // B5
                9'd108: mel_evt = {4'd1, 6'b111111};
                9'd109: mel_evt = {4'd1, 6'd40};   // E6
                9'd110: mel_evt = {4'd1, 6'd40};   // E6
                9'd111: mel_evt = {4'd1, 6'd37};   // C#6
                9'd112: mel_evt = {4'd1, 6'd35};   // B5
                9'd113: mel_evt = {4'd1, 6'd37};   // C#6
                9'd114: mel_evt = {4'd2, 6'd24};   // E5
                9'd115: mel_evt = {4'd1, 6'd35};   // B5
                9'd116: mel_evt = {4'd1, 6'd37};   // C#6
                9'd117: mel_evt = {4'd1, 6'd40};   // E6
                9'd118: mel_evt = {4'd1, 6'd35};   // B5
                9'd119: mel_evt = {4'd4, 6'd33};   // A5
                9'd120: mel_evt = {4'd1, 6'b111111};
                9'd121: mel_evt = {4'd1, 6'd33};   // A5
                9'd122: mel_evt = {4'd1, 6'd35};   // B5
                9'd123: mel_evt = {4'd1, 6'd37};   // C#6
                9'd124: mel_evt = {4'd1, 6'd40};   // E6
                9'd125: mel_evt = {4'd1, 6'd42};   // F#6
                9'd126: mel_evt = {4'd1, 6'd40};   // E6
                9'd127: mel_evt = {4'd1, 6'd37};   // C#6
                9'd128: mel_evt = {4'd1, 6'd40};   // E6
                9'd129: mel_evt = {4'd1, 6'd37};   // C#6
                9'd130: mel_evt = {4'd1, 6'd37};   // C#6
                9'd131: mel_evt = {4'd1, 6'd35};   // B5
                9'd132: mel_evt = {4'd4, 6'd35};   // B5
                9'd133: mel_evt = {4'd1, 6'b111111};
                9'd134: mel_evt = {4'd1, 6'd33};   // A5
                9'd135: mel_evt = {4'd1, 6'd35};   // B5
                9'd136: mel_evt = {4'd1, 6'd33};   // A5
                9'd137: mel_evt = {4'd2, 6'd35};   // B5
                9'd138: mel_evt = {4'd1, 6'd33};   // A5
                9'd139: mel_evt = {4'd1, 6'd35};   // B5
                9'd140: mel_evt = {4'd2, 6'd35};   // B5
                9'd141: mel_evt = {4'd2, 6'd37};   // C#6
                9'd142: mel_evt = {4'd1, 6'd40};   // E6
                9'd143: mel_evt = {4'd1, 6'd37};   // C#6
                9'd144: mel_evt = {4'd2, 6'd37};   // C#6
                9'd145: mel_evt = {4'd1, 6'b111111};
                9'd146: mel_evt = {4'd1, 6'd40};   // E6
                9'd147: mel_evt = {4'd1, 6'd40};   // E6
                9'd148: mel_evt = {4'd1, 6'd37};   // C#6
                9'd149: mel_evt = {4'd1, 6'd35};   // B5
                9'd150: mel_evt = {4'd1, 6'd37};   // C#6
                9'd151: mel_evt = {4'd2, 6'd26};   // F#5
                9'd152: mel_evt = {4'd1, 6'd35};   // B5
                9'd153: mel_evt = {4'd1, 6'd37};   // C#6
                9'd154: mel_evt = {4'd1, 6'd40};   // E6
                9'd155: mel_evt = {4'd1, 6'd37};   // C#6
                9'd156: mel_evt = {4'd4, 6'd35};   // B5
                9'd157: mel_evt = {4'd1, 6'b111111};
                9'd158: mel_evt = {4'd1, 6'd40};   // E6
                9'd159: mel_evt = {4'd1, 6'd40};   // E6
                9'd160: mel_evt = {4'd1, 6'd37};   // C#6
                9'd161: mel_evt = {4'd1, 6'd35};   // B5
                9'd162: mel_evt = {4'd1, 6'd37};   // C#6
                9'd163: mel_evt = {4'd2, 6'd24};   // E5
                9'd164: mel_evt = {4'd1, 6'd35};   // B5
                9'd165: mel_evt = {4'd1, 6'd37};   // C#6
                9'd166: mel_evt = {4'd1, 6'd40};   // E6
                9'd167: mel_evt = {4'd1, 6'd35};   // B5
                9'd168: mel_evt = {4'd4, 6'd33};   // A5
                9'd169: mel_evt = {4'd1, 6'b111111};
                9'd170: mel_evt = {4'd1, 6'd33};   // A5
                9'd171: mel_evt = {4'd1, 6'd35};   // B5
                9'd172: mel_evt = {4'd1, 6'd37};   // C#6
                9'd173: mel_evt = {4'd1, 6'd40};   // E6
                9'd174: mel_evt = {4'd1, 6'd42};   // F#6
                9'd175: mel_evt = {4'd1, 6'd40};   // E6
                9'd176: mel_evt = {4'd1, 6'd37};   // C#6
                9'd177: mel_evt = {4'd1, 6'd40};   // E6
                9'd178: mel_evt = {4'd1, 6'd37};   // C#6
                9'd179: mel_evt = {4'd1, 6'd37};   // C#6
                9'd180: mel_evt = {4'd1, 6'd35};   // B5
                9'd181: mel_evt = {4'd3, 6'd35};   // B5
                9'd182: mel_evt = {4'd1, 6'd40};   // E6
                9'd183: mel_evt = {4'd2, 6'd37};   // C#6
                9'd184: mel_evt = {4'd1, 6'd35};   // B5
                9'd185: mel_evt = {4'd1, 6'd35};   // B5
                9'd186: mel_evt = {4'd2, 6'd35};   // B5
                9'd187: mel_evt = {4'd2, 6'd33};   // A5
                9'd188: mel_evt = {4'd8, 6'd33};   // A5
                9'd189: mel_evt = {4'd2, 6'b111111};
                9'd190: mel_evt = {4'd1, 6'd37};   // C#6
                9'd191: mel_evt = {4'd1, 6'd40};   // E6
                default: mel_evt = {4'd4, 6'd32};
            endcase
        end
    endfunction

    // 两首曲子的长度（条目数-1）
    wire [5:0] MEL_LAST = song ? 6'd29 : 6'd41;

    reg [9:0]  mel_pos;              // ★ 10 位：表有 1024 项
    reg [26:0] mel_cyc;
    reg [9:0]  mel_cur;

    wire [9:0]  mel_nxt   = (mel_pos >= mel_last(song)) ? 10'd0 : mel_pos + 10'd1;
    wire [5:0]  mel_note  = mel_cur[5:0];
    wire [3:0]  mel_len   = mel_cur[9:6];        // 单位 = 16 分音符
    // ★ 兜底：时值 = 0 是【非法状态】，一旦出现就卡死 4.97 秒 ——
    //     mel_total = 0 -> mel_rel_at = 0 -> mel_rel 恒为 1 -> 门永远关着，
    //     而 mel_done 要等 mel_cyc 数到 (0-1) = 27'h7FFFFFF 才触发。
    //   上电复位值曾经因为（位宽截断 / 综合器常量折叠 / 异步复位装不了任意值）
    //   变成过 0，就是这个后果。这里兜成 1 拍，任何来源的 0 都不会再卡住。
    wire [3:0]  mel_len_g = (mel_len == 4'd0) ? 4'd4 : mel_len;
    wire [26:0] mel_total = mel_len_g * UNIT_CYC;  // 实际时长 = 单位数 x 单位长度
    wire        mel_done  = (mel_cyc == (mel_total - 27'd1));
    // 收音起点：留不住 RELEASE_CYC 的短音符就从头开始收音（防呆）
    wire [26:0] mel_rel_at = (mel_total > RELEASE_CYC)
                             ? (mel_total - RELEASE_CYC) : 27'd0;
    wire        mel_rel   = (mel_cyc >= mel_rel_at);

    //------------------------------------------------------------------
    //  曲目控制：S2 手动切歌 ＋【一首放完自动接下一首】
    //    ★ 2026-09-29 用户要求"自动播放循环播放所有音乐"，
    //      所以除了 S2，一首的最后一个音放完也会自动切到下一首。
    //    ★ 这个时序块原来在按键消抖那边，为了能引用 mel_done / mel_pos /
    //      mel_last（都在上面才声明）挪到了这里 —— 这个项目栽过
    //      "用在前、声明在后"：高云综合器容忍，但会静默推断成 1 位线网，
    //      只有 iverilog 会报。所以改完必须先跑 iverilog。
    //------------------------------------------------------------------
    // 旋律放完【最后一个事件】的那一拍 = 这一首结束了
    wire song_end = mel_done && (mel_pos >= mel_last(song));

    //  ★ SONG_CNT = 一共【填了谱子】几首。表容量是 8 首（song 是 3 位），
    //    加新歌就往这个数上加，别的地方不用动。
    localparam [2:0] SONG_CNT = 3'd3;

    // 下一首：到最后一首就绕回 0。
    //   ★ 写成 `song == SONG_CNT - 1` 而不是"先加一看有没有回绕" ——
    //     3 位在 song=7 时加 1 会自己溢出成 0，那种判断是错的。
    wire [2:0] song_inc = (song == SONG_CNT - 3'd1) ? 3'd0 : song + 3'd1;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            song     <= 2'd0;
            song_rst <= 1'b0;
        end else begin
            // 绕回到 SONG_CNT 以内的第 0 首。
            //   ★ 表能装 8 首，但只有前 SONG_CNT 首填了谱子 —— 切到空槽会去查
            //     default，弹出来是乱的。所以用 SONG_CNT 卡住。
            //   ★ 加歌时把它 +1 就行，这是唯一的开关。
            if (key2_press)    song <= song_inc;
            else if (song_end) song <= song_inc;

            // 为什么切歌要延迟一拍：
            //   song 是时序寄存器，按下那一拍读到的还是旧值。
            //   等下一拍再复位播放位置，才能取到新曲的第 0 个音。
            song_rst <= key2_press | song_end;
        end
    end

    // 查表下标 = {曲目, 曲内位置}。正常推进用 mel_nxt，复位/切歌取 0 号。
    // ★ 必须用【变量下标】而不是常量 —— GowinSynthesis 对"函数调用带常量参数"
    //   做常量折叠时会误报组合环(AG0100/AG0101)，报的信号名还是误导的。已实测。
    // ★ 这个下标里也不能引入 rst_n，同样会误报 AG0100。
    wire [9:0] mel_lookup = mel_base(song) + (song_rst ? 9'd0 : mel_nxt);
    wire [9:0] mel_evt_at = mel_evt(mel_lookup);
    // 上电要装的第 0 个音。三个坑都绕开了：
    //   ① 宽度必须 [9:0]（= mel_evt 返回宽度）。窄成 [7:0] 会把时值截成 0，
    //      门永远关着 -> 【上电后头 5 秒旋律是哑的】。
    //   ② 用变量下标 mel_base(song)，不用常量。
    //   ③ 复位只置 0（异步复位引脚只能置 0/1，装不了 288 这种值），
    //      真正的装载走下面 mel_init 那条普通时序路径。
    wire [9:0] mel_0_idx  = mel_base(song);
    wire [9:0] mel_evt_0  = mel_evt(mel_0_idx);

    // 上电装载脉冲：复位期间为高，复位释放后第一拍仍为高，之后恒低。
    // 用寄存器而不是直接用 rst_n，避免把复位信号引进组合逻辑（会触发 AG0100）。
    reg mel_init;
    always @(posedge clk or negedge rst_n)
        if (!rst_n) mel_init <= 1'b1;
        else        mel_init <= 1'b0;

    // "下一拍的值"用独立组合逻辑算清楚，时序块里只做无歧义的搬运。
    // 这样综合工具一眼就能看出"寄存器的反馈经过了一个明确的寄存器边界"，
    // 不会再去猜哪里有组合环（之前的写法会触发 AG0100 警告）。
    wire [7:0]  mel_pos_nxt = song_rst ? 8'd0 : (mel_done ? mel_nxt : mel_pos);
    wire [26:0] mel_cyc_nxt = (song_rst | mel_done) ? 27'd0 : (mel_cyc + 27'd1);
    wire [9:0]  mel_cur_nxt = (song_rst | mel_done) ? mel_evt_at
                            : (mel_init ? mel_evt_0 : mel_cur);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mel_pos <= 8'd0;
            mel_cyc <= 25'd0;
            mel_cur <= 10'd0;           // ★ 只能是 0：异步复位只能置 0/1
        end else begin
            mel_pos <= mel_pos_nxt;
            mel_cyc <= mel_cyc_nxt;
            mel_cur <= mel_cur_nxt;
        end
    end

    //==================================================================
    //              和弦：事件表（24 段 × 2 拍 = 48 拍）
    //   事件 = {时长[1:0], 和弦[1:0]}   和弦：0=C  1=F  2=G
    //
    //   每两拍换一次和弦，和上面旋律的 48 拍总长完全对齐，所以两个
    //   播放器永远同步（都是"拍"驱动，各自跑各自的表也不会漂）。
    //==================================================================
    // 两张和弦表合并成一张，索引规则同旋律表
    function [8:0] chd_evt;
        // ★ 入口宽度必须 >= 表里最大下标（现在最大是 80）。
        //   写成 [5:0] 的话，青花瓷的起始下标 64 会被截断成 0，
        //   表现为「和弦永远停在第 0 个（C 和弦）」，而且综合器和 iverilog 都不报错。
        input [8:0] i;
        begin
            case (i)
                // ---- 辞九门回忆和弦 ----
                8'd0   : chd_evt = {5'd16, 4'd0 };   // Ab
                8'd1   : chd_evt = {5'd16, 4'd0 };   // Ab
                8'd2   : chd_evt = {5'd16, 4'd2 };   // Eb
                8'd3   : chd_evt = {5'd16, 4'd0 };   // Ab
                8'd4   : chd_evt = {5'd16, 4'd2 };   // Eb
                8'd5   : chd_evt = {5'd16, 4'd0 };   // Ab
                8'd6   : chd_evt = {5'd16, 4'd1 };   // Db
                8'd7   : chd_evt = {5'd16, 4'd1 };   // Db
                // ---- 江南和弦 ----
                8'd32  : chd_evt = {5'd16, 4'd3 };   // Bb
                8'd33  : chd_evt = {5'd8 , 4'd12};   // Gm
                8'd34  : chd_evt = {5'd16, 4'd5 };   // F
                8'd35  : chd_evt = {5'd8 , 4'd12};   // Gm
                8'd36  : chd_evt = {5'd8 , 4'd3 };   // Bb
                8'd37  : chd_evt = {5'd8 , 4'd2 };   // Eb
                8'd38  : chd_evt = {5'd8 , 4'd5 };   // F
                8'd39  : chd_evt = {5'd16, 4'd2 };   // Eb
                8'd40  : chd_evt = {5'd16, 4'd5 };   // F
                8'd41  : chd_evt = {5'd8 , 4'd12};   // Gm
                8'd42  : chd_evt = {5'd8 , 4'd3 };   // Bb
                8'd43  : chd_evt = {5'd16, 4'd2 };   // Eb
                8'd44  : chd_evt = {5'd16, 4'd3 };   // Bb
                // ---- 青花瓷副歌（弱起1拍 + 16 段 x 2 拍）----
                8'd64 : chd_evt = {5'd4, 4'd6};   // D
                8'd65 : chd_evt = {5'd8, 4'd7};   // E
                8'd66 : chd_evt = {5'd8, 4'd8};   // C#m
                8'd67 : chd_evt = {5'd8, 4'd9};   // F#m
                8'd68 : chd_evt = {5'd8, 4'd10};   // Bm
                8'd69 : chd_evt = {5'd8, 4'd7};   // E
                8'd70 : chd_evt = {5'd8, 4'd11};   // A
                8'd71 : chd_evt = {5'd8, 4'd11};   // A
                8'd72 : chd_evt = {5'd8, 4'd6};   // D
                8'd73 : chd_evt = {5'd8, 4'd7};   // E
                8'd74 : chd_evt = {5'd8, 4'd8};   // C#m
                8'd75 : chd_evt = {5'd8, 4'd9};   // F#m
                8'd76 : chd_evt = {5'd8, 4'd10};   // Bm
                8'd77 : chd_evt = {5'd8, 4'd7};   // E
                8'd78 : chd_evt = {5'd8, 4'd11};   // A
                8'd79 : chd_evt = {5'd8, 4'd11};   // A
                8'd80 : chd_evt = {5'd8, 4'd11};   // A
                default: chd_evt = {5'd8, 4'd0};
            endcase
        end
    endfunction

    // 两首曲子的和弦表长度
    wire [4:0] CHD_LAST = song ? 5'd15 : 5'd23;

    reg [8:0]  chd_pos;              // ★ 9 位：表有 512 段
    reg [26:0] chd_cyc;
    reg [8:0]  chd_cur;

    wire [8:0]  chd_nxt   = (chd_pos >= chd_last(song)) ? 9'd0 : chd_pos + 9'd1;
    wire [3:0]  chd_val   = chd_cur[3:0];        // 12 个和弦，需要 4 位
    wire [4:0]  chd_len   = chd_cur[8:4];        // 单位 = 16 分音符
    wire [26:0] chd_total = chd_len * UNIT_CYC;
    wire        chd_done  = (chd_cyc == (chd_total - 27'd1));
    wire [26:0] chd_rel_at = (chd_total > RELEASE_CYC)
                             ? (chd_total - RELEASE_CYC) : 27'd0;
    wire        chd_rel   = (chd_cyc >= chd_rel_at);

    // 查表下标 = {曲目, 曲内位置}，规则同旋律
    wire [8:0] chd_lookup = chd_base(song) + (song_rst ? 8'd0 : chd_nxt);
    wire [8:0] chd_evt_at = chd_evt(chd_lookup);
    wire [8:0] chd_evt_0  = chd_evt(9'd0);

    // 和旋律播放器同样的写法：下一拍的值组合地算好，时序块只做搬运
    wire [6:0]  chd_pos_nxt = song_rst ? 7'd0 : (chd_done ? chd_nxt : chd_pos);
    wire [26:0] chd_cyc_nxt = (song_rst | chd_done) ? 27'd0 : (chd_cyc + 27'd1);
    wire [8:0]  chd_cur_nxt = (song_rst | chd_done) ? chd_evt_at : chd_cur;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            chd_pos <= 7'd0;
            chd_cyc <= 25'd0;
            chd_cur <= chd_evt_0;       // 上电复位：C 和弦
        end else begin
            chd_pos <= chd_pos_nxt;
            chd_cyc <= chd_cyc_nxt;
            chd_cur <= chd_cur_nxt;
        end
    end

    // ---- 键号 -> 音符号 ----
    // ★ 实际接线顺序和假设不同时，只需要重排这一张表。键号 = row*4 + col。
    // KBD_ALL_TEST=1 时所有键都发 KBD_ALL_NOTE（排查用）；正常必须是 0。
    localparam [5:0] KBD_ALL_NOTE = 6'b10_1001;   // A5
    localparam       KBD_ALL_TEST = 1'b0;

    function [5:0] kbd_note;
        input [3:0] k;
        begin
            if (KBD_ALL_TEST) begin
                kbd_note = KBD_ALL_NOTE;
            end else begin
                case (k)
                    4'd0 : kbd_note = 6'b00_0000;   // C3   低音 1
                    4'd1 : kbd_note = 6'b00_0010;   // D3        2
                    4'd2 : kbd_note = 6'b00_0100;   // E3        3
                    4'd3 : kbd_note = 6'b00_0101;   // F3        4
                    4'd4 : kbd_note = 6'b00_0111;   // G3        5
                    4'd5 : kbd_note = 6'b00_1001;   // A3        6
                    4'd6 : kbd_note = 6'b00_1011;   // B3        7
                    4'd7 : kbd_note = 6'b01_0000;   // C4   中音 1
                    4'd8 : kbd_note = 6'b01_0010;   // D4        2
                    4'd9 : kbd_note = 6'b01_0100;   // E4        3
                    4'd10: kbd_note = 6'b01_0101;   // F4        4
                    4'd11: kbd_note = 6'b01_0111;   // G4        5
                    4'd12: kbd_note = 6'b01_1001;   // A4        6
                    4'd13: kbd_note = 6'b01_1011;   // B4        7
                    4'd14: kbd_note = 6'b10_0000;   // C5   高音 1
                    //  ★ 2026-09-30：15 号键【恢复成音符】了（原来是音色键，
                    //    音色搬到外接按键上）。键盘现在是 16 个音：低音1 ~ 高音2。
                    4'd15: kbd_note = 6'b10_0010;   // D5   高音 2
                    default: kbd_note = 6'b00_0000;
                endcase
            end
        end
    endfunction

    //==================================================================
    //  临时测试：按 S1 自动扫一遍键盘音阶（低音1 -> 高音2）
    //==================================================================
    //  ★ 2026-11-01 用户要求：暂时不用外接键盘，按一下板载 S1，
    //    让 16 个音从低到高依次响一遍（0.5 秒一个，共 8 秒）。
    //  ★ S1 原来是"自动演奏开/关"。现在改成触发这个扫描。
    //  ★ 扫描期间【键盘整体停用】（见下面的 KBD_BYPASS），
    //    同时把自动演奏的门也关掉 —— 不然歌声和音阶混在一起听不清。
    //  ★ 想恢复键盘：把 KBD_BYPASS 改成 0 就行，别的不用动。
    localparam       KBD_BYPASS = 1'b0;
    localparam [24:0] SWEEP_STEP = 25'd13500000;   // 每音 0.5 秒 @27MHz
    //  ★★ 每两个音之间必须让门【落下 30ms】★★
    //    踩过的坑：第一版门全程保持高电平、只在换音时改音高，
    //    结果只听到第一声"do"，之后声音越来越小。
    //    原因：拨弦声部是靠【门的上升沿】触发拨弦的 —— 门不落下，
    //    弦就一直是同一根、只被拨过一次，后面的音高变了也没人重新拨弦，
    //    第一声的余音衰减完就没声了。
    //    （波表音色不会这样，它只要改频率就行；但吉他必须重新拨。）
    localparam [24:0] SWEEP_GAP  = 25'd810000;     // 30ms @27MHz

    reg        sweep_run;
    reg [4:0]  sweep_idx;
    reg [24:0] sweep_cnt;
    reg [5:0]  sweep_note;
    //  门是组合出来的：每个音的前 30ms 落下，之后抬起
    wire       sweep_gate = sweep_run && (sweep_cnt >= SWEEP_GAP);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sweep_run  <= 1'b0;
            sweep_idx  <= 5'd0;
            sweep_cnt  <= 25'd0;
            sweep_note <= 6'b00_0000;          // 低音1（C3），直接写值不用函数
        end else if (1'b0 && key1_press && !sweep_run) begin
            //  ★ 2026-11-01：扫音阶的触发【已摘掉】—— 它是键盘旁路时用的测试功能，
            //    现在 KBD_BYPASS=0（键盘正常），这个功能用不上，而且它会白占 8 秒。
            //    代码留着（改回 key1_press 就能复现），但默认不启动。
            sweep_run  <= 1'b1;
            sweep_idx  <= 5'd0;
            sweep_cnt  <= 25'd0;
            sweep_note <= 6'b00_0000;          // 低音1（门由 sweep_gate 组合给出）
        end else if (sweep_run) begin
            if (sweep_cnt == SWEEP_STEP) begin
                sweep_cnt <= 25'd0;            // 归零 = 门落下 30ms
                if (sweep_idx == 5'd15) begin  // 高音2 放完 -> 结束
                    sweep_run <= 1'b0;
                end else begin
                    sweep_idx  <= sweep_idx + 5'd1;
                    sweep_note <= kbd_note(sweep_idx[3:0] + 4'd1);
                end
            end else begin
                sweep_cnt <= sweep_cnt + 25'd1;
            end
        end
    end

    //==================================================================
    //  编码器诊断②：碰一下就响一声（2026-11-01，仅 ENC_DIAG=1 时生效）
    //==================================================================
    //  为什么不用 LED：来回好几次，"哪盏灯亮"这个信息在转述中失真了。
    //  改用声音 —— 音箱是好的，碰一下响一声，一听就知道通没通。
    //    碰 S1（30）-> 响 低音1
    //    碰 S2（31）-> 响 高音1   （音高差两个八度，绝不会听混）
    //  ★ 只在【下降沿】触发一次，松手不响。
    //  ★ 2026-11-01 23:1x：这两个触发条件补了 ENC_DIAG 门控。
    //    以前没有门控 —— 只是碰巧 KBD_BYPASS=0 时 beep 根本不进混音，
    //    所以听不见；一旦有人把 KBD_BYPASS 改成 1（停键盘扫音阶），
    //    转旋钮就会一路"哔哔哔"。这个坑留着迟早有人踩。
    //  ★ 触发源改用【消抖后】的 enc_s1_lev/enc_s2_lev：用原始脚的话，
    //    触点抖动一次会响好几声，白占 8 秒发声位。
    localparam [24:0] BEEP_LEN = 25'd4050000;      // 150ms @27MHz

    reg [24:0] beep_cnt;
    reg        beep_run;
    reg [5:0]  beep_note;
    reg        s1_d, s2_d;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1_d <= 1'b1; s2_d <= 1'b1;
            beep_run <= 1'b0; beep_cnt <= 25'd0; beep_note <= 6'd0;
        end else begin
            s1_d <= enc_s1_lev;
            s2_d <= enc_s2_lev;
            if (ENC_DIAG && enc_s1_lev & ~s1_d) begin         // S1 下降沿
                beep_run <= 1'b1; beep_cnt <= 25'd0; beep_note <= 6'b00_0000;  // 低音1
            end else if (ENC_DIAG && enc_s2_lev & ~s2_d) begin // S2 下降沿
                beep_run <= 1'b1; beep_cnt <= 25'd0; beep_note <= 6'b10_0000;  // 高音1
            end else if (beep_run) begin
                if (beep_cnt == BEEP_LEN) beep_run <= 1'b0;
                else                      beep_cnt <= beep_cnt + 25'd1;
            end
        end
    end

    //==================================================================
    //                    门的产生 与 各路音高
    //==================================================================
    // 自动演奏总开关（S1 一下切换，上电为 1）。拉低后只剩键盘，方便单独弹。
    //   song 只在 0..2 之间绕，所以查表函数永远命中真分支、不会走 default。
    //  ★ 扫音阶期间把歌声关掉 —— 不然两样混在一起听不出音阶
    //  ★ 诊断期间（ENC_DIAG=1）歌声一直关掉，只听"碰一下响一声"
    wire mel_gate = auto_on && !mel_rel && (mel_note != N_REST) && !sweep_run && !ENC_DIAG;
    wire chd_gate = auto_on && !chd_rel && !sweep_run && !ENC_DIAG;

    // 青花瓷整首降了 8 个半音，所以它的和弦用另一张表，保持和旋律同一调性
    wire [5:0]  c_n0 = (song == 2'd2) ? chord_note_qh(chd_val, 2'd0) : chord_note(chd_val, 2'd0);
    wire [5:0]  c_n1 = (song == 2'd2) ? chord_note_qh(chd_val, 2'd1) : chord_note(chd_val, 2'd1);
    wire [5:0]  c_n2 = (song == 2'd2) ? chord_note_qh(chd_val, 2'd2) : chord_note(chd_val, 2'd2);

    //------------------------------------------------------------------
    //  ★ 吉他声部要的是【音符号】，不是频率控制字 —— 而且必须【锁存】★
    //    门一落，mel_note 立刻变成下一个事件（青花瓷里还有 N_REST 休止），
    //    不锁存的话，正在余音的那根弦会【突然变调】再止音。
    //    键盘那边踩过一模一样的坑（见 note_kr0 的注释）。
    //    锁存条件用"门开着"：门开着的时候音符号一定是合法的。
    //------------------------------------------------------------------
    reg [5:0] mel_note_r, c_n0_r, c_n1_r, c_n2_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            mel_note_r <= 6'd0;
            c_n0_r     <= 6'd0;
            c_n1_r     <= 6'd0;
            c_n2_r     <= 6'd0;
        end else begin
            if (mel_gate) mel_note_r <= mel_note;
            if (chd_gate) begin
                c_n0_r <= c_n0;
                c_n1_r <= c_n1;
                c_n2_r <= c_n2;
            end
        end
    end

    //==================================================================
    //  4x4 按键矩阵键盘：15 个键弹自然音阶（低音1 ~ 高音1，C3~C5），
    //  第 16 键（bit 15）= 音色键。15 个键固定在这个八度，不再有八度键。
    //==================================================================
    wire [15:0] kbd_keys;
    wire [3:0]  kbd_gate_alloc;
    wire [3:0]  kbd_k0, kbd_k1, kbd_k2, kbd_k3;

    keypad u_kbd (
        .clk   (clk),
        .rst_n (rst_n),
        .row   (kbd_row),
        .col   (kbd_col),
        .keys  (kbd_keys)
    );

    voice_alloc u_alloc (
        .clk   (clk),
        .rst_n (rst_n),
        .keys  (kbd_keys),
        .gate  (kbd_gate_alloc),
        .k0    (kbd_k0), .k1 (kbd_k1), .k2 (kbd_k2), .k3 (kbd_k3)
    );

    // ---- S15(键14) / S16(键15) = 【音量键】，按一下变一档 ----
    //   ★ 2026-09-29 改的：这两个键原来是"高音1"和"音色切换键"。
    //     为了腾出音量键，键盘音域从 低音1~高音1 缩到 低音1~中音7（少了最高那个音）。
    //     音色键没了 —— 所以键盘音色【固定成吉他】（和自动演奏一致，
    //     用户说过那个好听）。要改回钢琴就把 KBD_TIMBRE 改成 1'b0。
    //   ★ 音量档 0..12，增益 = 档位 / 2^VOL_SHIFT（VOL_SHIFT 见混音器那一段）：
    //       0  = 静音
    //       VOL_SHIFT = 5 时：12 -> 0.375，3 -> 0.094
    //   ★ 没有屏了，所以按一下让 led[3] 亮 0.1 秒做个"收到了"的反馈
    //     （led[3] 原来是音色指示，现在音色固定了，正好改成这个用）。
    localparam        TIMBRE_DEF = 1'b1;      // 上电默认音色：1=吉他 0=钢琴（外接按键可切）
    localparam [4:0]  VOL_MAX    = 5'd12;
    //  ★ 2026-11-01：上电默认音量。
    //    以前是 VOL_MAX（增益 x3）。换成 PCM5102A + 有源音箱之后，
    //    数字增益 12 档出来的电平太响（用户说"吵到别人"）。
    //    ★ 调过三轮：12 -> 6 还是太大 -> 3（x0.75）-> 再把整体衰减 8 倍。
    //      有源音箱那头的增益比原来板载功放大得多，所以数字这边要压得更狠。
    //    ★ 现在默认这一档的实际增益约 0.094，大约是原来板载喇叭版本的 1/8。 
    //       关键换算看 VOL_SHIFT（混音器那一段），不在这里。
    //    上电就停在这一档，之后全靠旋钮调。
    localparam [4:0]  VOL_DEF    = 5'd3;
    //  旋钮一转就把它装满，装满之前 6 个灯显示音量条（约 0.8 秒）
    localparam [24:0] FLASH_CYC  = 25'd21600000;  // 约 800ms @27MHz

    //  ★★ 2026-09-30：这三个功能从【键盘的 S15/S16】搬到了【外接按键】★★
    //    用户外接了三个两脚按键：音量+ / 音量- / 音色切换。
    //    键盘 16 个键【全部还给音符】—— 当初为音量键牺牲掉的 高音1 回来了，
    //    而且现在有 16 个键，音域变成 低音1 ~ 高音2。
    //    ⇒ 所以下面【不再有 kbd_keys[15:14] 这回事】了。
    reg [4:0]  vol;
    reg [24:0] flash_cnt;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vol       <= VOL_DEF;
            flash_cnt <= 25'd0;
        end else begin
            //  音量只由旋钮驱动
            if (enc_up) begin
                if (vol < VOL_MAX) vol <= vol + 5'd1;
            end else if (enc_dn) begin
                if (vol > 5'd0) vol <= vol - 5'd1;
            end

            //  音量条的点亮条件用 enc_act（动一下就亮），不是 enc_up/enc_dn
            //  （攒满一格才亮）—— 这样"有信号但没解码出来"也能看见，
            //  比"什么都不显示"好排查得多。
            if (enc_act) begin
                flash_cnt <= FLASH_CYC;
            end else if (flash_cnt != 25'd0) begin
                flash_cnt <= flash_cnt - 25'd1;
            end
        end
    end

    //------------------------------------------------------------------
    //  上电淡入（2026-11-01 换 PCM5102A + 外接音响后新增）
    //
    //  ---- 为什么需要 ----
    //    以前是板载小喇叭：上电那一下的"咔"又轻又闷，听不出来。
    //    现在后面接了功放 + 音箱，同一道电平和时钟跳变会被放大成
    //    一声很明显的闷响 —— 这不是数据有问题，是 DAC 起振瞬间的正常现象，
    //    只能靠"让它慢慢出声"遮住。
    //
    //  ---- 怎么做的（★ 不额外占用乘法器）----
    //    不是给输出再乘一个渐变系数（那要多一个乘法器），
    //    而是让【送进原来那个乘法器的音量】从 0 爬到目标值：
    //        mix_v = mix_s * vol_f / 4
    //    vol_f 每 FADE_STEP 拍加 1，从 0 追到 vol 就停。
    //    12 档 x 10ms = 120ms 爬满，听感上是一个很短的"渐入"。
    //
    //  ---- 两个边界 ----
    //    · 旋钮【调大】：vol_f 慢慢跟（本来就是斜坡，看不出区别）
    //    · 旋钮【调小】：vol_f 立刻跟过去 —— 不能拖 120ms，
    //      否则想静音的时候按了半秒还在响，那是 bug 不是淡入
    //    · 复位期间 vol_f 是 0，所以每次重新配置后也是从静音开始
    //------------------------------------------------------------------
    localparam [21:0] FADE_STEP = 22'd270000;   // 10ms @ 27MHz

    reg [21:0] fade_cnt;
    reg [4:0]  vol_f;                            // 实际送进乘法的音量

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            vol_f    <= 5'd0;
            fade_cnt <= 22'd0;
        end else if (vol_f > vol) begin
            vol_f    <= vol;                     // 调小：立刻跟
            fade_cnt <= 22'd0;
        end else if (vol_f < vol) begin
            if (fade_cnt == FADE_STEP) begin
                fade_cnt <= 22'd0;
                vol_f    <= vol_f + 5'd1;
            end else begin
                fade_cnt <= fade_cnt + 22'd1;
            end
        end else begin
            fade_cnt <= 22'd0;                   // 追上了就停在原地
        end
    end

    //------------------------------------------------------------------
    //  升降八度：低 / 中 / 高 三档，按一下往上走一档、到头绕回低。
    //  ★ 只作用于【键盘】。自动演奏的三首歌固定在原音域 ——
    //    因为板载小喇叭 250Hz 以下推不动（实测过），整首歌降八度会发虚。
    //  ★ 音符号 = {八度[1:0], 半音[3:0]}，八度在高 2 位，
    //    所以升一个八度就是 +16（写 +4 只是升 4 个半音，别搞错）。
    //  ★ 到边界【夹住】而不是回绕：低档时最低那个键就停在最低音，
    //    不然它会突然跳到最高音去。
    //------------------------------------------------------------------
    reg [1:0] oct;                  // 0 = 低，1 = 中（上电默认），2 = 高

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)            oct <= 2'd1;
        else if (btn_oct_press) oct <= (oct == 2'd2) ? 2'd0 : oct + 2'd1;
    end


    //------------------------------------------------------------------
    //  音色切换：吉他（Karplus-Strong 拨弦）/ 钢琴（波表 + ADSR）
    //
    //  ★★ 2026-09-30：钢琴声部的包络参数在下面例化处【逐个覆盖】了 ★★
    //    用户反馈"钢琴特别浑浊，应该是清脆的"。根因不是波形，是包络：
    //    voice.v 的默认 ENV_SUS = 22937（0.70 满幅）—— 意思是衰减到 70%
    //    就【永远停住】。键一直按着就是一个稳定的持续音 = 那是风琴，不是钢琴。
    //    真钢琴【键按着音也会自己消失】。
    //      · ENV_SUS = 0        -> 衰减一路到 0，不再有延音
    //      · D_DIV   = 1000     -> 衰减时间从 150ms 拉到约 1.2 秒
    //    （真钢琴大约 1~3 秒。嫌长/短就改 D_DIV，它是【每一步多少时钟】，
    //     总时长 = 32767 x D_DIV / 27MHz。）
    //  ★ 只切【键盘】。自动演奏那 4 路声部是 ks_voice（吉他），
    //    工程里没有对应的波表版本 —— 要一起切得再加 4 个 voice 实例，
    //    先不做。
    //  ★ 两条通路【一直在跑】，这里只是选谁进混音器（见下面的 kbd_lvl），
    //    所以切换是瞬间的，没有重启动的爆音。
    //------------------------------------------------------------------
    reg timbre;                     // 0 = 钢琴，1 = 吉他（自动演奏 + 键盘【一起】切）

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)            timbre <= TIMBRE_DEF;      // 上电默认（见常量）
        else if (btn_tb_press) timbre <= ~timbre;
    end

    //==================================================================
    //  测试模式：8 路纯正弦，给【现场验证复音数】用
    //==================================================================
    //  ---- 为什么必须有这个 ----
    //  赛题现场验证要求："支持测试模式下输出多路不同频率音频，
    //  频谱可观测对应数量独立谱峰"。弹和弦不行 —— 频谱糊成一团，数不出峰。
    //  必须有一个"8 路同时响、每路一个固定音高"的状态，
    //  手机频谱 App 一照就是 8 根分得很开的尖峰。
    //
    //  ---- ★ 为什么不能用现成的 sine_rom ★ ----
    //  src/sine_rom.v 名字叫 sine，但【实测它是钢琴音色波表】：
    //  250Hz 基频下 2 次谐波只低 6.9dB、THD 约 57%。
    //  拿它当测试音，8 路会变成 8 组谐波簇 = 几十根峰，根本数不出来，
    //  而且现场看起来像是软件 bug，排查方向完全跑偏。
    //  所以单独生成了一份真正弦 src/test_sine_rom.v（THD 0.0001%）。
    //  ★ 教训：别信文件名的自我描述，量了才算数。
    //
    //  ---- 8 个音怎么挑的 ----
    //  · 范围 250Hz~2kHz：板载小喇叭 250Hz 以下推不动（实测过），
    //    手机麦克风在低频也不准，两端都避开。
    //  · 【等比】排开而不是音阶：音阶的半音间隔在小字组只有十几 Hz，
    //    手机 FFT 分不开。等比排开最小间隔也有 86Hz，一眼能数。
    //
    //  ---- 怎么进 / 怎么出 ----
    //  把【音色键】按住约 1 秒 = 进/出。短按仍然是切音色。
    //  进去之后 led[3] 常亮。
    reg        test_mode;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) test_mode <= 1'b0;
        // 旋钮 KEY长按到点的那一拍翻转一次（tb_long_fired 松手前不会重复置位）
        else if (tb_long_fired & ~tb_fired_d) test_mode <= ~test_mode;
    end

    // 频率控制字 = f x 2^32 / 46875。实测误差 < 0.02%。
    //   ★ 写成 localparam 而不是"带常量参数的函数调用" —— 高云综合器对后者
    //     做常量折叠时会误报组合环 AG0100/AG0101（实测过，报的信号名还误导）。
    localparam [31:0] T_INC0 = 32'd22906492,    //  250 Hz
                      T_INC1 = 32'd30694700,    //  335 Hz
                      T_INC2 = 32'd41231686,    //  450 Hz
                      T_INC3 = 32'd55891841,    //  610 Hz
                      T_INC4 = 32'd75133295,    //  820 Hz
                      T_INC5 = 32'd100788566,   // 1100 Hz
                      T_INC6 = 32'd135606434,   // 1480 Hz
                      T_INC7 = 32'd183251938;   // 2000 Hz

    wire signed [15:0] tw0, tw1, tw2, tw3, tw4, tw5, tw6, tw7;

    test_osc u_t0 (.clk(clk), .rst_n(rst_n), .tick(fs_tick), .phase_inc(T_INC0), .wave(tw0));
    test_osc u_t1 (.clk(clk), .rst_n(rst_n), .tick(fs_tick), .phase_inc(T_INC1), .wave(tw1));
    test_osc u_t2 (.clk(clk), .rst_n(rst_n), .tick(fs_tick), .phase_inc(T_INC2), .wave(tw2));
    test_osc u_t3 (.clk(clk), .rst_n(rst_n), .tick(fs_tick), .phase_inc(T_INC3), .wave(tw3));
    test_osc u_t4 (.clk(clk), .rst_n(rst_n), .tick(fs_tick), .phase_inc(T_INC4), .wave(tw4));
    test_osc u_t5 (.clk(clk), .rst_n(rst_n), .tick(fs_tick), .phase_inc(T_INC5), .wave(tw5));
    test_osc u_t6 (.clk(clk), .rst_n(rst_n), .tick(fs_tick), .phase_inc(T_INC6), .wave(tw6));
    test_osc u_t7 (.clk(clk), .rst_n(rst_n), .tick(fs_tick), .phase_inc(T_INC7), .wave(tw7));

    // 8 路满幅相加是 ±262136（19 位够），>>5 后 ±8191。
    //   ★ 为什么是 >>5 而不是 >>3：后面还要过音量乘法（最大档 x3），
    //     >>3 的话 8191x4x3 直接削顶 —— 削顶生谐波，频谱上反而多出峰来，
    //     正好毁掉这个模式要证明的东西。>>5 留足余量。
    wire signed [18:0] tst_sum = tw0 + tw1 + tw2 + tw3 + tw4 + tw5 + tw6 + tw7;
    wire signed [23:0] tst_lvl = tst_sum >>> 5;



    // ★ 音高只在【门开着】的时候更新。
    //   否则松键时 voice_alloc 把键号清成 4'hF，而 kbd_note(4'hF) 返回 C3，
    //   收音那一段会以 C3 发声 —— 听感就是每个音后面拖一个很小的低音。
    //   代价：按下后晚 1 拍（37ns）更新音高，那一拍包络刚从 0 起音，听不出。
    // 四个键盘声部当前该发什么音（6'h3F = 该声部空着）。
    //  ★ 八度移位就加在这一层：kbd_n0..n3 之后【两条音色通路、OLED、混音器】
    //    全都跟着走，不用每处各改一遍。
    //  ★ 八度移位就加在这一层：kbd_n0..n3 之后【两条音色通路、OLED、混音器】
    //    全都跟着走，不用每处各改一遍。
    //  ★ 这里【故意不写成函数】—— 原来写成 function oct_shift() 是读不到
    //    模块级 reg oct 的（仿真里三档都返回原值，移位根本不生效，
    //    而 iverilog 不报错）。展开成四条 wire 就对了，也更好查。
    wire [5:0] kb0_raw = (kbd_k0 == 4'hF) ? 6'h3F : kbd_note(kbd_k0);
    wire [5:0] kb1_raw = (kbd_k1 == 4'hF) ? 6'h3F : kbd_note(kbd_k1);
    wire [5:0] kb2_raw = (kbd_k2 == 4'hF) ? 6'h3F : kbd_note(kbd_k2);
    wire [5:0] kb3_raw = (kbd_k3 == 4'hF) ? 6'h3F : kbd_note(kbd_k3);

    // 低档：降一个八度，已到最低就夹住；高档：升一个八度，已到最高就夹住
    //  ★ KBD_BYPASS=1 时键盘整组停用，只有第 0 路跟着扫音阶走
    wire [3:0] kbd_gate = KBD_BYPASS ? {3'b000, (sweep_gate | beep_run)}
                                     : kbd_gate_alloc;

    wire [5:0] kbd_n0 = KBD_BYPASS ? (beep_run  ? beep_note :
                                      sweep_gate ? sweep_note : 6'h3F)
                                    : (kb0_raw == 6'h3F) ? 6'h3F : (oct == 2'd0) ? ((kb0_raw[5:4] == 2'd0) ? kb0_raw : kb0_raw - 6'b01_0000)
                                            : (oct == 2'd2) ? ((kb0_raw[5:4] == 2'd3) ? kb0_raw : kb0_raw + 6'b01_0000) : kb0_raw;
    wire [5:0] kbd_n1 = KBD_BYPASS ? 6'h3F
                                    : (kb1_raw == 6'h3F) ? 6'h3F : (oct == 2'd0) ? ((kb1_raw[5:4] == 2'd0) ? kb1_raw : kb1_raw - 6'b01_0000)
                                            : (oct == 2'd2) ? ((kb1_raw[5:4] == 2'd3) ? kb1_raw : kb1_raw + 6'b01_0000) : kb1_raw;
    wire [5:0] kbd_n2 = KBD_BYPASS ? 6'h3F
                                    : (kb2_raw == 6'h3F) ? 6'h3F : (oct == 2'd0) ? ((kb2_raw[5:4] == 2'd0) ? kb2_raw : kb2_raw - 6'b01_0000)
                                            : (oct == 2'd2) ? ((kb2_raw[5:4] == 2'd3) ? kb2_raw : kb2_raw + 6'b01_0000) : kb2_raw;
    wire [5:0] kbd_n3 = KBD_BYPASS ? 6'h3F
                                    : (kb3_raw == 6'h3F) ? 6'h3F : (oct == 2'd0) ? ((kb3_raw[5:4] == 2'd0) ? kb3_raw : kb3_raw - 6'b01_0000)
                                            : (oct == 2'd2) ? ((kb3_raw[5:4] == 2'd3) ? kb3_raw : kb3_raw + 6'b01_0000) : kb3_raw;

    reg [31:0] pinc_kr0, pinc_kr1, pinc_kr2, pinc_kr3;
    // ★ 吉他还需要【锁存音符号】。ks_voice 的延迟线长度是 note 直接算出来的
    //   （不像波表只影响频率），松键时 kbd_n* 变成 6'h3F -> 延迟长度变成 716
    //   -> 正在余音的那根弦会【突然变调】再止音。和 pinc_kr* 同样的锁法。
    reg [5:0]  note_kr0, note_kr1, note_kr2, note_kr3;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pinc_kr0 <= 32'd0;
            pinc_kr1 <= 32'd0;
            pinc_kr2 <= 32'd0;
            pinc_kr3 <= 32'd0;
            note_kr0 <= 6'd0;
            note_kr1 <= 6'd0;
            note_kr2 <= 6'd0;
            note_kr3 <= 6'd0;
        end else begin
            if (kbd_gate[0]) begin pinc_kr0 <= note_pinc(kbd_n0); note_kr0 <= kbd_n0; end
            if (kbd_gate[1]) begin pinc_kr1 <= note_pinc(kbd_n1); note_kr1 <= kbd_n1; end
            if (kbd_gate[2]) begin pinc_kr2 <= note_pinc(kbd_n2); note_kr2 <= kbd_n2; end
            if (kbd_gate[3]) begin pinc_kr3 <= note_pinc(kbd_n3); note_kr3 <= kbd_n3; end
        end
    end

    //==================================================================
    //                        8 个声部
    //==================================================================
    wire signed [15:0] v0, v1, v2, v3, v4, v5, v6, v7;

    //------------------------------------------------------------------
    //  自动演奏 4 路：也是【吉他】（Karplus-Strong）
    //    ★ 原来这里用的是波表 voice + ADSR 包络。换成 ks_voice 之后：
    //      · 音符号直接进延迟长度表（不需要频率控制字 note_pinc）
    //      · ADSR 包络不要了 —— 拨弦的自然衰减【就是】包络
    //      · 每换一个音 = 门重新拉高 = 重新拨一次弦，正是吉他该有的行为
    //    音符号用锁存后的 mel_note_r / c_n*_r（门低时冻结，见上面的注释）。
    //------------------------------------------------------------------
    ks_voice u_v0 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),   // 旋律
                .gate(mel_gate), .note(mel_note_r), .sample(v0));

    ks_voice u_v1 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),   // 和弦根音
                .gate(chd_gate), .note(c_n0_r),     .sample(v1));

    ks_voice u_v2 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),   // 和弦三音
                .gate(chd_gate), .note(c_n1_r),     .sample(v2));

    ks_voice u_v3 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),   // 和弦五音
                .gate(chd_gate), .note(c_n2_r),     .sample(v3));

    //  ★ w0..w3 必须【先声明】，下面例化就要用 —— 这个项目栽过"用在前、声明在后"：
    //    高云综合器容忍并把信号静默推断成 1 位线网，只有 iverilog 会报。
    wire signed [15:0] w0, w1, w2, w3;

    //  ★ 2026-09-30：自动演奏的【钢琴】声部（4 路波表），和上面的 ks_voice 并行跑。
    //    原来自动演奏只有吉他 —— 用户要求"音色键也要切自动播放"。
    //    音符号 -> 频率控制字用现成的 note_pinc()（键盘那 4 路就是这么算的）。
    //    ★ 音高必须和上面那 4 路 ks_voice 用【同一个】锁存音符号
    //      （mel_note_r / c_n0_r..c_n2_r），这样两种音色切换时音高完全一致。
    //  ★ 2026-11-02：这里原来是 voice #(.R_DIV(10'd47), .D_DIV(10'd1000),
    //    .ENV_SUS(16'sd0))，线性 ADSR + 静态波表，音色是"锯齿波 + 匀速渐弱"。
    //    换成 piano_voice：双段指数衰减 + 亮度随包络下降（见文件末尾的模块）。
    //    想回退成旧音色：把这 8 行的 piano_voice 改回
    //        voice #(.R_DIV(10'd47), .D_DIV(10'd1000), .ENV_SUS(16'sd0))
    //    即可（voice.v 还在，没删）。
    piano_voice u_w0 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                .gate(mel_gate), .phase_inc(note_pinc(mel_note_r)), .sample(w0));
    piano_voice u_w1 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                .gate(chd_gate), .phase_inc(note_pinc(c_n0_r)),     .sample(w1));
    piano_voice u_w2 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                .gate(chd_gate), .phase_inc(note_pinc(c_n1_r)),     .sample(w2));
    piano_voice u_w3 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                .gate(chd_gate), .phase_inc(note_pinc(c_n2_r)),     .sample(w3));

    // 键盘声部：voice_alloc 分配，最多 4 键同时发声。
    //   phase_inc 用锁存后的 pinc_kr*（门低时冻结，见上）。
    //   R_DIV=47 -> 收音 40ms（默认 141 = 120ms，对键盘太长，尾巴会压到下一个音上）。
    piano_voice u_v4 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                .gate(kbd_gate[0]), .phase_inc(pinc_kr0), .sample(v4));

    piano_voice u_v5 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                .gate(kbd_gate[1]), .phase_inc(pinc_kr1), .sample(v5));

    piano_voice u_v6 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                .gate(kbd_gate[2]), .phase_inc(pinc_kr2), .sample(v6));

    piano_voice u_v7 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                .gate(kbd_gate[3]), .phase_inc(pinc_kr3), .sample(v7));

    //------------------------------------------------------------------
    //  ★ 这两组声部【一直并行在跑】，音色键只负责选谁进混音器（见下面 kbd_lvl），
    //    所以切换是瞬间的，没有重启的爆音。代价是多 4 块 BSRAM。
    //    资源：每根弦 1 块 BSRAM + 1 个乘法器（插值用），共 4+4。
    //    ★ tick 必须是 fs_tick：环路是"每采样走一趟"，不是每时钟。
    //------------------------------------------------------------------
    wire signed [15:0] k0, k1, k2, k3;

    ks_voice u_ks0 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                    .gate(kbd_gate[0]), .note(note_kr0), .sample(k0));

    ks_voice u_ks1 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                    .gate(kbd_gate[1]), .note(note_kr1), .sample(k1));

    ks_voice u_ks2 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                    .gate(kbd_gate[2]), .note(note_kr2), .sample(k2));

    ks_voice u_ks3 (.clk(clk), .rst_n(rst_n), .tick(fs_tick),
                    .gate(kbd_gate[3]), .note(note_kr3), .sample(k3));

    //==================================================================
    //                          混音
    //==================================================================
    // 先把每路符号扩展到 24 位再加，避免加法链在 16 位里溢出
    wire signed [23:0] m0 = {{8{v0[15]}}, v0};
    wire signed [23:0] m1 = {{8{v1[15]}}, v1};
    wire signed [23:0] m2 = {{8{v2[15]}}, v2};
    wire signed [23:0] m3 = {{8{v3[15]}}, v3};
    wire signed [23:0] m4 = {{8{v4[15]}}, v4};
    wire signed [23:0] m5 = {{8{v5[15]}}, v5};
    wire signed [23:0] m6 = {{8{v6[15]}}, v6};
    wire signed [23:0] m7 = {{8{v7[15]}}, v7};
    //  ★ 自动演奏的钢琴声部（波表），和 m0..m3 一一对应。
    //    名字里的 w = wave（波表），和 p = pluck（拨弦）是两套音色。
    wire signed [23:0] m0w = {{8{w0[15]}}, w0};
    wire signed [23:0] m1w = {{8{w1[15]}}, w1};
    wire signed [23:0] m2w = {{8{w2[15]}}, w2};
    wire signed [23:0] m3w = {{8{w3[15]}}, w3};
    wire signed [23:0] p0 = {{8{k0[15]}}, k0};
    wire signed [23:0] p1 = {{8{k1[15]}}, k1};
    wire signed [23:0] p2 = {{8{k2[15]}}, k2};
    wire signed [23:0] p3 = {{8{k3[15]}}, k3};

    // 分层：旋律一路、和弦三路、键盘四路，各自带自己的音量
    //  ★ 钢琴那边多移【2】位而不是 1 位 —— 实测（tb_audiopath）：
    //    波表声部的原始峰值是 31499（几乎满量程），吉他 ks_voice 只有 6298，
    //    差 5 倍。只移 1 位的话钢琴仍比吉他响 2.06 倍（量出来的），移 2 位才平。
    //    电平不对也会让人觉得"浑浊" —— 削顶出来的失真听起来就是糊的。
    //  ★★ 2026-11-02 换了钢琴波表 + 加了亮度低通之后的电平修正（三层都要）★★
    //    实测（sim/tb_piano.v 的 20~40ms 窗口）：
    //      旧：波表峰值 32767，RMS 20149   （8 谐波全同相）
    //      新：峰值 22537，RMS 10411       （16 谐波扩散相位 + 两级低通）
    //    ⇒ 比值 0.517，要补 1.94 倍，正好取 2（移位少 1 位，精确、零成本）。
    //    ★ 峰值是 22537 而不是旧的 32767，乘 2 之后是 45074，看着超标 ——
    //      但这里算出的是 24 位中间量，混音后还要 >>>5 再乘 vol/32，
    //      离 16 位饱和还差很远，不会削顶。
    //    三处（旋律/和弦/键盘）必须【同时】补，否则层间比例会变。
    wire signed [23:0] mel_lvl
        = timbre ? (m0 >>> MEL_SHIFT)
                 : (m0w >>> (MEL_SHIFT + 1));

    // 和弦层增益 = 主旋律（这条比例是用户反复调出来的）。
    //   ★ 2026-09-29 换成吉他声部后重算过：吉他的【原始峰值只有波表的约 1/3】
    //     （实测：波表单音进混音 0.062 @>>4  ->  原始 ≈0.99；
    //            吉他单音进混音 0.041 @>>3  ->  原始 ≈0.33），
    //     所以同一条移位量下吉他天然小三倍。要"音量听不出变化"就得整体抬 3 倍。
    //   三路最大和，吉他从 3x32767 变成 3x16320 = 48960；旋律要 1020 -> 需要 ≈1/46.4。
    //   ★ 单次移位只能给 1/32 或 1/64，差一倍（6dB），所以用"移位相加"
    //     拼出 1/64 + 1/256 + 1/512 = 1/46.5（只高 0.1dB）。
    //   ★ 第一版写的是 1/64+1/128+1/256 = 1/36.6，算错了 —— 那是 1.27 倍，
    //     和弦会比旋律大 2.4dB。是 check_rtl.py 的 [C] 段报出来的
    //     （它从 RTL 里读常量算"旋律/和弦 幅度比"，期望 ≈1.03）。
    //   改 MEL_SHIFT 时这里要同步改，否则和弦的相对音量会变。
    //  ★ 两套声部的【原始幅度差约 3 倍】（吉他拨弦比波表小），
    //    所以钢琴那边要多移 2 位（实测波表原始峰值 31499 vs 拨弦 6298 = 5 倍，
    //    2^2=4 最接近）。键盘层用的是同一个关系：KS_SHIFT 和 KS_SHIFT+2。
    wire signed [23:0] chd_sum   =   m1 + m2 + m3;
    wire signed [23:0] chd_sum_w =   m1w + m2w + m3w;
    //  钢琴侧先算一次 1/46.5 的和，再整体少移 1 位（新的 RMS 补偿，见 mel_lvl 那段）
    wire signed [23:0] chd_w
        = ((chd_sum_w >>> 6) + (chd_sum_w >>> 8) + (chd_sum_w >>> 9)) >>> 2;
    wire signed [23:0] chd_lvl   
        = timbre ? ((chd_sum   >>> 6) + (chd_sum   >>> 8) + (chd_sum   >>> 9))
                 : chd_w;
    // 键盘层：4 路共用一条移位，音色不同分开算。4 键齐按合计 4 倍。
    //   KBD_SHIFT=4 -> 每键 2047（旋律 1023 的 2 倍），4 键 8188。
    //   ★ 弹键盘通常只按 1~2 个键，所以"单键有多响"比"4 键合计"更该盯。
    //   ★ 音色二选一：钢琴走波表 v4~v7，吉他走 ks_voice k0~k3。
    //     两套声部都在跑，这里只是选谁进混音器。
    //     吉他单独一条移位 KS_SHIFT。
    //     ★ 这个值是【端到端仿真实测】调出来的，不是估的 ——
    //       一开始按 tb_ks 的"峰值 0.6 满幅"估成 4，结果顶层 tb_timbre
    //       录到的峰值是：钢琴单音 0.062  vs  吉他单音 0.0205（KS_SHIFT=4）
    //       峰值差 3 倍 = 9.6dB，切换音色时会明显觉得吉他小一截。
    //       原因：tb_ks 那个 0.6 是【含起音瞬态】的峰值，持续段没这么大。
    //       改成 3（响 2 倍）后吉他峰值约 0.041，贴近钢琴。
    //       剩下的差距是拨弦的本质（按下去就在衰减），不该再补。
    //       （RMS 差 27dB 是对的：持续音 vs 拨弦，本来就该差这么多。）
    //     ★ 觉得吉他还是小声/太响，就调这一个数：-1 = 响一倍，+1 = 减半。
    wire signed [23:0] kbd_sum_p = p0 + p1 + p2 + p3;
    wire signed [23:0] kbd_sum_m = m4 + m5 + m6 + m7;
    //  ★ 钢琴多移【两位】—— 实测原始峰值：波表 31499 vs 拨弦 6298，正好差 5 倍
    //    （2^2 = 4，最接近；多移一位就变成只有吉他的 0.62 倍了）。
    //    ★ 这【不是】用"某个时刻的峰值"量出来的 —— 那种量法会被包络形状骗到：
    //      拨弦已经衰下去了、钢琴才刚起音，两边根本不是同一时刻。
    //   ★ 2026-11-02：钢琴侧少移 1 位（×2）—— 新音色的 RMS 只有旧的 0.517 倍，
    //     补偿量见 mel_lvl 上面那段。吉他侧不动（ks_voice 没改）。
    wire signed [23:0] kbd_lvl   = timbre ? (kbd_sum_p >>> KS_SHIFT)
                                          : (kbd_sum_m >>> (KS_SHIFT + 1));

    reg signed [23:0] mix_sum;

    always @(posedge clk)
        // 测试模式【顶掉】正常输出，不是叠加 —— 叠加会把自动演奏的音混进来，
        // 频谱上多出来的峰就不是那 8 个了
        mix_sum <= test_mode ? tst_lvl : (mel_lvl + chd_lvl + kbd_lvl);

    //------------------------------------------------------------------
    //  总输出音量
    //    ★ 2026-09-29：用户在真机上反馈"不够响"，要 3 倍。
    //    ★ 3 不是 2 的幂，移位给不了 —— 用"移位相加"：x*3 = x + (x<<1)，一个加法器。
    //    ★ 必须【饱和】而不是截断。3 倍之后最坏情况会超过 16 位，
    //      单纯取低 16 位会变成【极性翻转】（从最大正跳到最大负）——
    //      那是"爆音"，比削顶难听得多，而且听起来像坏了。
    //    ★ 为什么敢加 3 倍：端到端仿真实测，自动演奏的峰值只有
    //      1749/32767 = 5.3%，离满幅还差 25dB。
    //      理论最坏情况（4 键齐按 + 旋律 + 和弦同时拉满）* 3 = 61614，
    //      那种情况会削顶 —— 但实际不会同时发生。
    //    ★ 想再响/回退，就改下面 mix_g 那一行：
    //        x2 = mix_s <<< 1
    //        x3 = mix_s + (mix_s <<< 1)        <- 现在用的
    //        x4 = mix_s <<< 2
    //        x6 = (mix_s <<< 2) + (mix_s <<< 1)
    //------------------------------------------------------------------
    wire signed [24:0] mix_s = mix_sum;                 // 先符号扩展到 25 位
    // 音量：增益 = vol / 2^VOL_SHIFT
    //   ★ 用乘法器而不是移位 —— 移位只能给 2 的幂，13 档里大半给不出来。
    //     DSP 有余量（11/24），一个乘法器不心疼。
    //   ★ vol 必须显式当【无符号正数】送进乘法：不写 $signed({1'b0, vol})
    //     的话整个乘法的符号性会被带偏，负半周会算错。
    //   ★ 这里用的是 vol_f 而不是 vol —— vol_f 是"从 0 爬到 vol"
    //     的斜坡，用来遮掉上电爆音（见 vol_f 那一段）。稳态时两者相等。
    //
    //   ★★ 2026-11-01 第二次衰减：用户说换了音箱之后"太吵"，要求小 10 倍 ★★
    //     原来是 >>> 2，增益 = vol/4，默认 vol=3 时 0.75。
    //     现在 >>> 5，增益 = vol/32，默认 vol=3 时 0.0938 —— 正好小 8 倍（-18dB）。
    //     10 倍没法用移位表示（只能 8 倍或 16 倍），8 倍更接近，先落这一档。
    //     ★ 还嫌吵：VOL_SHIFT 加 1（每次再减半，6 = 16 倍）
    //     ★ 太小了：VOL_SHIFT 减 1
    //     ★ 旋钮通了之后最高档 12/32 = 0.375，比现在的默认响 4 倍，够用。
    localparam VOL_SHIFT = 5;

    wire signed [30:0] mix_v = (mix_s * $signed({1'b0, vol_f})) >>> VOL_SHIFT;

    assign mix_out = (mix_v >  31'sd32767) ?  16'sd32767 :
                     (mix_v < -31'sd32768) ? -16'sd32768 : mix_v[15:0];

    //==================================================================
    //                      I2S 发射
    //==================================================================
    i2s_tx u_i2s (
        .clk      (clk),
        .rst_n    (rst_n),
        .sample_l (mix_out),
        .sample_r (mix_out),
        .bck      (HP_BCK),
        .ws       (HP_WS),
        .din      (HP_DIN),
        .fs_tick  (fs_tick)
    );

    //==================================================================
    //                       输出级 / 板载功放
    //
    //  PA_EN (pin 51) 接的是板载 MAX98357A 的 SD_MODE：
    //    高 = 使能（板上那颗小喇叭会出声）
    //    低 = 关断（输出高阻，不耗电、也不会把 BCLK 的边沿耦合出噪声）
    //
    //  ★ 2026-11-01：音频改从 PCM5102A 走了，板载功放已经没负载，
    //    再让它开着只是白耗电。⇒ 默认【关断】。
    //
    //  ★ 想两路同时出声（比如调试时还想听板载小喇叭），把这里改成 1'b1
    //    就行 —— 一键回退，别的地方一个字都不用动。
    //
    //  ★ 不把 PA_EN 改接 PCM5102A 的 XSMT（软静音）的理由：
    //    ① 那样是【低电平才静音】，和现在"高=使能"反相，容易接反导致没声；
    //    ② 模块上的 XSMT 直接接 3.3V 就够用；
    //    ③ 上电爆音已经由前面的 vol_f 淡入解决了，不需要额外软静音。
    //==================================================================
    localparam KEEP_BOARD_AMP = 1'b0;     // 0 = 关断板载功放（默认），1 = 保留

    assign PA_EN = KEEP_BOARD_AMP;

    //==================================================================
    //                  OLED 显示屏（SSD1306 128x64, I2C）
    //   ★ 和音频通路【完全独立】：I2C 是另一条时序，不碰混音也不碰发声。
    //     唯一的共享点是它读几个状态信号（歌曲/音符号），全是只读的。
    //     ⇒ 加屏不会给音频带来任何回归风险。
    //
    //   显示内容：当前歌曲 + 自动演奏的旋律音 + 键盘按下的音（简谱数字+八度点）
    //   接线：OLED VCC->板子 3V3，GND->GND，SCL->71，SDA->72
    //==================================================================
    wire        oled_we;
    wire [9:0]  oled_waddr;
    wire [7:0]  oled_wdat;
    wire        oled_ack_err;      // 从机没应答（诊断用：仿真里可以抓它）
    wire        oled_addr_ok;      // ★ 模块有没有应答 I2C 地址（接到 led[4] 诊断）

    oled_ui u_oled_ui (
        .clk      (clk),
        .rst_n    (rst_n),
        .song     (song),
        .mel_note (mel_note_r),
        .kbd_n0   (kbd_n0),
        .kbd_n1   (kbd_n1),
        .kbd_n2   (kbd_n2),
        .kbd_n3   (kbd_n3),
        .kbd_gate (kbd_gate),
        .we       (oled_we),
        .waddr    (oled_waddr),
        .wdat     (oled_wdat)
    );

    oled_ssd1306 u_oled (
        .clk      (clk),
        .rst_n    (rst_n),
        .we       (oled_we),
        .waddr    (oled_waddr),
        .wdat     (oled_wdat),
        .ready    (),
        .busy     (),
        .addr_ok  (oled_addr_ok),
        .scl      (oled_scl),
        .sda      (oled_sda),
        .sda_in   (oled_sda),
        .ack_err  (oled_ack_err)
    );

    //==================================================================
    //                          LED 显示
    //==================================================================
    reg [23:0] led_cnt;
    reg        led_r;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            led_cnt <= 24'd0;
            led_r   <= 1'b0;
        end else if (led_cnt == 24'd6749999) begin   // 0.25s
            led_cnt <= 24'd0;
            led_r   <= ~led_r;
        end else begin
            led_cnt <= led_cnt + 1'b1;
        end
    end

    //  ★ 诊断开关（2026-09-29）★
    //    OLED 不亮时，最难判断的是"I2C 到底通没通"—— 全黑看不出原因。
    //    置 1 时把 led[4] 从"有键按着"改成显示【模块有没有应答 I2C 地址】：
    //        led[4] 灭 = 模块应答了 → I2C 通了，问题在别处
    //        led[4] 亮 = 模块没应答 → 接线/供电/地址问题
    //    屏调通之后改回 0 即可（或者一直留着，反正有键按着也能从声音听出来）。
    //  ★ 2026-11-01：OLED 模块已确认是坏硬件，这个诊断关掉 ——
    //    关掉之后 led[4] 恢复成"有键按着"，比一直显示"I2C 不通"有用。
    //    （以后换了新屏想再查 I2C，把它改回 1 就行。）
    localparam OLED_DIAG = 1'b0;

    //==================================================================
    //  ★ 编码器故障定位（ENC_DIAG = 1 时生效；2026-11-01 重写）
    //==================================================================
    //  只做一件事：把 S1/S2 的【真实电平】和【有没有动过】原样摆到 6 个灯上。
    //  引脚 30(S1) / 31(S2)。慢速转旋钮时，两个电平灯应该按 11 -> 01 -> 00 -> 10
    //  的顺序轮流亮灭（只接对一路的话只有一位在动 —— 这正是 76/80 那次的症状）。
    //
    //  ★ 怎么看（板载 6 个 LED 是【共阳极、低电平点亮】，
    //    所以下面一律写"亮 = ..."，不谈电平，免得再被极性坑一次）：
    //      led[5]  心跳          —— 一直闪 = 板子在跑（不闪就别往下看了）
    //      led[4]  KEY 按下      —— 按住旋钮时亮
    //      led[3]  S2 现在是低    —— 转旋钮时闪
    //      led[2]  S1 现在是低    —— 转旋钮时闪
    //      led[1]  S2 曾经低过    —— 锁存：见过一次低就一直亮，松手也不灭
    //      led[0]  S1 曾经低过
    //
    //  ★ 这张表能直接把故障定位到环节：
    //      只有心跳在闪             -> S1/S2 根本没接到，或模块没供电
    //      电平灯不动、锁存灯也不亮  -> 同上（是"没信号"，不是"信号慢"）
    //      锁存灯亮但电平灯不动      -> 碰过一下（比如手碰线），没真正接通
    //      电平灯按 11/01/00/10 走   -> 解码一定通，问题在音量那一段
    //      只有一路灯在动            -> 有一根线没接好
    //
    //  ★ 上一版的极性是反的：文档写"碰地时亮"，代码实际是"高电平时亮"
    //    （`led = ~led_data` + 共阳极，led_data 写 1 才是亮）。
    //    这一版逐位对着 `led = ~led_data` 核过：下面 led_diag 里写 1 就是亮。
    //  ★ 用的是【同步之后】的 enc_now，和解码器看的是同一个信号 ——
    //    这样"灯对了但音量不动"才有意义（说明问题不在输入侧）。
    //==================================================================
    reg s1_ever, s2_ever;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1_ever <= 1'b0;
            s2_ever <= 1'b0;
        end else begin
            if (!enc_now[1]) s1_ever <= 1'b1;      // enc_now[1] = S1
            if (!enc_now[0]) s2_ever <= 1'b1;      // enc_now[0] = S2
        end
    end

    wire [5:0] led_normal = {led_r,                                    // led[5] 心跳
                             (OLED_DIAG ? ~oled_addr_ok : |kbd_gate),  // led[4]
                             (test_mode | ~timbre),                    // led[3]
                             auto_on,                                  // led[2]
                             song[1:0]};                               // led[1:0] 曲目

    //------------------------------------------------------------------
    //  音量条（转旋钮时临时顶掉上面那组显示）
    //  ★ 2026-11-01 定型：6 格纯音量条，一格 2 档（vol 0..12）
    //       vol=0  -> 全灭，一眼看出"已静音"
    //       vol=12 -> 6 个全亮
    //    上一版这里还留了 led[1]/led[0] 当"哪一路有信号"的通道灯，
    //    那是排查 76/80 时加的；旋钮已经通了，那两个位还给音量条，
    //    显示更直观，也少两个跨模块的 wire。
    //------------------------------------------------------------------
    wire [5:0] led_vol = {(vol >= 5'd12),        // led[5]
                          (vol >= 5'd10),        // led[4]
                          (vol >= 5'd8),         // led[3]
                          (vol >= 5'd6),         // led[2]
                          (vol >= 5'd4),         // led[1]
                          (vol >= 5'd2)};        // led[0]

    wire vol_show = (flash_cnt != 25'd0);

    //  ★★ 2026-11-01：这个声明【原来漏了】★★
    //    原来直接写 `assign led_data = ...` 而没有声明，Verilog 会把它当成
    //    【隐式 1 位线网】—— 右边 6 位被截成 1 位（EX3791: size 6 -> 1），
    //    于是 6 个灯永远只有"全亮 / 全灭"两种状态，心跳灯也从来没亮过。
    //    这也是之前"照着灯去判断故障"一直对不上的根源。
    wire [5:0] led_data;

    //  每一位 = 1 就是【亮】（`assign led = ~led_data` 是共阳极取反）
    wire [5:0] led_diag = {led_r,          // led[5] 心跳
                           btn_tb_db,      // led[4] KEY 按下
                           ~enc_now[0],    // led[3] S2 现在是低
                           ~enc_now[1],    // led[2] S1 现在是低
                           s2_ever,        // led[1] S2 曾经低过
                           s1_ever};       // led[0] S1 曾经低过

    assign led_data = ENC_DIAG ? led_diag : (vol_show ? led_vol : led_normal);

    assign led = ~led_data;              // 共阳极：低电平点亮

endmodule


//======================================================================
//  piano_voice  --  钢琴声部（2026-11-02 新增，替换原来的 voice.v）
//======================================================================
//  为什么换掉 voice.v（voice.v 保留着没删，想回退就把实例名改回去）：
//    voice.v 的问题是三件事同时不对，而三件事正是"像不像钢琴"的全部：
//
//    ① 【包络是线性衰减】env 每 D_DIV 拍减 1，从 32767 到 0 是 1.2 秒
//       匀速下降。听感像有人匀速拉渐弱旋钮 —— 弦的振幅从来是指数衰减的，
//       所以真实钢琴是"砰 -> 快速掉一截 -> 长长的不紧不慢的余音"。
//       -> 这里改成【双段指数】：env -= env>>13（前段，τ≈175ms），
//          跌到 8192 以下切换成 env -= env>>14（后段，τ≈350ms）。
//          env 从满到 -60dB 约 2.2 秒，起音后 240ms 掉 12dB，正是钢琴样子。
//        ★ 纯移位实现，零乘法器。
//
//    ② 【衰减期间音色完全不变】静态波表 + 单一包络，谐波只能"一起变大
//       变小"。真实钢琴高次谐波衰减得比基波【快】，所以音色由亮变暗。
//       这一条是"像钢琴"最关键的一条，光换波表永远做不到。
//       -> 这里加一阶低通，系数用【包络自己】当控制量：
//              y += (x - y) >> lp_sh(env)
//          env 大 -> 移位少 -> 截止高 -> 亮；env 小 -> 移位多 -> 暗。
//          实测截止频率从 5.2kHz（起音，保留 20 次谐波）滑到约 1kHz
//          （尾音，只剩 4 次谐波）。
//        ★ 用【可变移位】而不是乘法，所以【零额外乘法器】—— 每声部
//          仍然只有包络那一个乘法，资源和 voice.v 基本一样。
//
//    ③ 【起音太慢】voice.v 的 A_DIV=8 是 9.7ms，钢琴锤击是 1~3ms。
//       慢起音听起来是"呼"的一下吹进来（风琴/弦乐），不是"当"的一下。
//       -> A_DIV=2 约 2.4ms。
//
//  另外：按住不放时 env 衰减到 0 就静音，不会重新起音 —— 靠 gate_rise
//  而不是 gate 电平触发，否则衰减到底会立刻"再敲一次"，变成循环敲击。
//======================================================================
module piano_voice (
    input  wire               clk,
    input  wire               rst_n,
    input  wire               tick,        // 1 clk 脉冲，每个采样周期一次
    input  wire               gate,        // 高 = 按住，低 = 松键（制音器落下）
    input  wire [31:0]        phase_inc,
    output reg  signed [15:0] sample
);

    localparam [15:0] ENV_PEAK = 16'd32767;
    localparam [9:0]  A_DIV    = 10'd2;      // 起音 ~2.4ms

    //------------------------------------------------------------------
    //  振荡器（波表是 src/sine_rom.v，现在装的是 16 谐波钢琴表）
    //------------------------------------------------------------------
    wire signed [15:0] wave;

    dds_osc u_osc (
        .clk       (clk),
        .rst_n     (rst_n),
        .tick      (tick),
        .phase_inc (phase_inc),
        .wave      (wave)
    );

    //------------------------------------------------------------------
    //  门沿检测：只在"按下去那一下"起音，不能按电平反复起音
    //------------------------------------------------------------------
    reg gate_d;

    always @(posedge clk or negedge rst_n)
        if (!rst_n) gate_d <= 1'b0;
        else        gate_d <= gate;

    wire gate_rise = gate & ~gate_d;

    //------------------------------------------------------------------
    //  包络：快起音 -> 双段指数衰减 -> （松键时）快速制音
    //
    //  ★★ env 为什么是 24 位而不是 16 位 ★★
    //    这是【定点做指数衰减最容易栽的坑】，第一版就栽了：
    //    若 env 只有 16 位整数，env -= (env>>14) 在 env 掉到 16384 以下时
    //    env>>14 恒等于 0，衰减立刻退化成"每拍减 1"的【直线】——
    //    于是 350ms 就把余音削光了（实测：2.2 秒的仿真里 300ms 后全静音）。
    //    加 8 位小数（低 8 位是 1/256 幅度）后，env>>13 在整条曲线上
    //    都保持"按比例"递减，指数律才真的是指数律。
    //    代价：一个 24 位寄存器 + 移位器，零乘法器。
    //------------------------------------------------------------------
    localparam [2:0] S_IDL = 3'd0,
                     S_ATK = 3'd1,
                     S_DEC = 3'd2,
                     S_REL = 3'd3;

    //  ★ 衰减律最后定成【单段指数 τ≈350ms】（移位 14），不再分两段。
    //    试过双段（前段 τ≈175ms 只走一小段 + 后段 τ≈350ms），标定两次都不对：
    //      切换点 8192  -> 259ms 就 -21dB，听起来是木琴/马林巴
    //      切换点 24576 -> 2s 已经 -65dB，余音没了
    //    原因是双段的实际曲线对切换点极其敏感，而"前段再快一点"带来的
    //    那点锤击感，用 2.4ms 的快起音已经能够表达。
    //    单段 τ=350ms 实测（相对峰值）：
    //      0.26s -7dB / 0.5s -13dB / 1s -25dB / 2s -50dB，到听不见约 2.5s
    //    —— 这就是真实钢琴 C4 的量级，而且只有一个常数，好调好懂。

    reg [2:0]  st;
    reg [23:0] env;                          // 高 16 位 = 幅度，低 8 位 = 小数
    reg [9:0]  a_div;

    wire [15:0] env16 = env[23:8];

    // 每采样减掉自身的一个固定比例 = 指数衰减。
    //   +1 是保险：env 小到移位出 0 时也还能往下走，不会卡死。
    //
    //  ★★ 2026-11-02 15:0x：τ 从 350ms 收紧到 175ms（>>14 -> >>13）★★
    //    原因：自动演奏的音符只有 107ms 门高（RELEASE_CYC 吃掉了尾部 120ms），
    //    而 τ=350ms 在 107ms 里只掉 2.4dB —— 音头几乎是【平的】，
    //    听起来像"嘟嘟"的矩形包络，没有琴槌落下去的动感，也就是用户说的"闷"。
    //    τ=175ms 时 107ms 掉 5.3dB，音头才有"落"的形状。
    wire [23:0] dec_step = (env >> 13) + 24'd1;
    // 松键：τ≈8192 采样≈175ms，到听不见约 1.4s —— 像制音器慢慢落下
    //
    //  ★★ 2026-11-02 15:0x：从 >>10（22ms）大幅放慢到 >>13 ★★
    //    这是"嘀嘀嘀像电报"的正面修复。原来 22ms 就把音掐死，而相邻两个
    //    音符之间门要低 120ms，于是每个音都是"响一下 -> 死寂 -> 再响一下"。
    //    改 175ms 后：门落 120ms 处余音还有 -6dB，正好和下个音的起音搭上，
    //    听感从"点"变成"线"，这才是钢琴连奏的样子。
    wire [23:0] rel_step = (env >> 13) + 24'd1;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st    <= S_IDL;
            env   <= 24'd0;
            a_div <= 10'd0;
        end else begin
            case (st)
                S_IDL: begin
                    env   <= 24'd0;
                    a_div <= 10'd0;
                    if (gate_rise) st <= S_ATK;
                end
                S_ATK: begin
                    if (!gate) begin
                        st <= S_REL;
                    end else if (a_div == (A_DIV - 10'd1)) begin
                        a_div <= 10'd0;
                        if (env16 >= ENV_PEAK) st  <= S_DEC;
                        else                   env <= env + 24'd256;  // +1 个幅度单位
                    end else begin
                        a_div <= a_div + 10'd1;
                    end
                end
                S_DEC: begin
                    if (!gate) begin
                        st <= S_REL;
                    end else if (tick) begin
                        // 自然衰减到 0 就静音（钢琴按住不放也会消失）
                        if (env <= dec_step) begin
                            env <= 24'd0;
                            st  <= S_IDL;
                        end else begin
                            env <= env - dec_step;
                        end
                    end
                end
                S_REL: begin
                    if (gate_rise) begin
                        st <= S_ATK;            // 还没收完又按下 -> 重新起音
                    end else if (tick) begin
                        if (env <= rel_step) begin
                            env <= 24'd0;
                            st  <= S_IDL;
                        end else begin
                            env <= env - rel_step;
                        end
                    end
                end
                default: begin
                    st  <= S_IDL;
                    env <= 24'd0;
                end
            endcase
        end
    end

    //------------------------------------------------------------------
    //  亮度低通：y += (x - y) >> lp_sh
    //
    //  ★★ 2026-11-02 15:0x：这里原来有个【安静的 bug】，是"沉闷"的真正原因 ★★
    //    旧代码用 lp_sh(env[23:21])，3 位，case 表却按 16 位环境写成
    //    "7,6 -> >>1 / 5,4 -> >>2 / 3 -> >>3 ..."。
    //    但钢琴波表峰值 = 32767 = 0b0111_1111_1111_1111，
    //    高 3 位最多只到 4 —— 表里 7/6/5 三档【永远命中不了】。
    //    结果起音一开始就落到 "4 -> >>2"，两级一阶 -3dB 点只有 1.2kHz，
    //    旋律区（C5=523Hz）连 3 次谐波都被砍了 => 听起来又闷又糊。
    //
    //    现在改成取 env[23:20]（4 位，实际可达 0..7，共 8 档）：
    //      7,6  -> 0   全通，起音完全不加滤波（保留全部 16 次谐波）
    //      5,4  -> 1   一级 3.7k / 两级 2.4k
    //      3    -> 2   一级 1.9k / 两级 1.2k
    //      2    -> 3   一级 933 / 两级 597
    //      1    -> 4   一级 466 / 两级 298
    //      0    -> 5   一级 233 / 两级 149（只剩基波，很暗的尾音）
    //    档位按 -2.5dB / -6dB / -12dB / -20dB / 更弱 分布，
    //    既保住了"尾音越来越暗"这个钢琴特征，又不再一上来就砍高频。
    //
    //  ★ 为什么不用乘法算系数：每声部省一个乘法器。8 个声部就是 8 个，
    //    而 DSP 只剩 13 块，用可变移位（综合成桶形移位器，只吃 LUT）零成本。
    //------------------------------------------------------------------
    function [3:0] lp_sh;
        input [3:0] e4;
        begin
            case (e4)
                4'd7, 4'd6 : lp_sh = 4'd0;
                4'd5, 4'd4 : lp_sh = 4'd1;
                4'd3      : lp_sh = 4'd2;
                4'd2      : lp_sh = 4'd3;
                4'd1      : lp_sh = 4'd4;
                default   : lp_sh = 4'd5;
            endcase
        end
    endfunction

    wire [3:0]        lp_s = lp_sh(env[23:20]);
    reg  signed [16:0] lp;                 // 第一级状态（17 位，防溢出）
    reg  signed [16:0] lp2;                // 第二级状态
    wire signed [16:0] lp_d  = wave - lp;  // 与目标的差
    wire signed [16:0] lp_d2 = lp - lp2;   // 第一级到第二级

    //  ★ 为什么串【两级】一阶：
    //    一阶只有 -6dB/oct，实测尾音（800ms，-30dB）在 1kHz 以上还剩 3.1%
    //    的能量，听起来尾巴还是"沙沙"的，不像钢琴那种只剩基波的暗余音。
    //    两级串联 = -12dB/oct，同样的截止频率下 1kHz 处多衰减 12dB，
    //    尾音才真的暗下来。代价只是每声部多一个 17 位寄存器，仍然零乘法器。
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            lp  <= 17'sd0;
            lp2 <= 17'sd0;
        end else if (tick) begin
            lp  <= lp  + (lp_d  >>> lp_s);
            lp2 <= lp2 + (lp_d2 >>> lp_s);
        end
    end

    //------------------------------------------------------------------
    //  包络相乘（打一拍帮助时序收敛）
    //------------------------------------------------------------------
    wire signed [15:0] lp16 = lp2[15:0];
    reg  signed [31:0] mul;

    always @(posedge clk) mul <= lp16 * $signed({1'b0, env16});

    always @(posedge clk) sample <= mul[30:15];     // >> 15 归一化

endmodule


//======================================================================
//  enc_dec  --  旋转编码器正交解码器（一对 S1/S2）
//======================================================================
//  ★ 为什么这个模块写在【本文件内部】而不是单独的 enc_dec.v：
//    高云 IDE 综合时读的是 impl/gwsynthesis/synth.prj，而那份文件列表
//    是 IDE 从【它自己内存里的工程状态】生成的，不是每次去解析 .gprj。
//    所以往 .gprj 里加新文件后，除非在 IDE 里关闭/重开工程（或者手动
//    Add Files），综合器根本看不到新文件，报的错就是：
//        ERROR (EX3937) : Instantiating unknown module 'enc_dec'
//    而本文件始终在列表里 —— 把定义放这里就再也不依赖工程配置，
//    谁拿到这一份 synth_top.v 都能直接综合。
//
//  设计原则：宁可"多算一格"，也不能"整段转动一个数都不加"。
//
//  ---- ① 每路独立消抖 500us ----
//    既滤掉触点抖动，又顺带把异步输入同步掉：要求"连续 DEB_N 拍都不一致"
//    才承认变化，等于强制外来信号稳定下来才采信，亚稳态早收敛了。
//
//  ---- ② 相邻状态查表判方向 ----
//        顺时针 00->01->11->10->00
//        逆时针 00->10->11->01->00
//    ★ 两路同时变（斜对角 00<->11 / 01<->10）【不丢弃】，按"沿上一次
//      方向继续"记一格。人手拧快了一下就能越过两个状态，丢了就是
//      "越转越没反应"——这正是上一版解码器的老毛病，必须改掉。
//
//  ---- ③ 累加器围绕中点摆动 ----
//    攒够 PER_STEP 次【同向】跳变才走一格，走完回中点。
//    抖动是 +1/-1 来回，围绕中点自然抵消，攒不出假的一格。
//    全是无符号比较，不依赖综合器对有符号参数表达式的处理。
//
//  ---- ④ 通道活动指示 ----
//    s1_hot / s2_hot：最近 HOLD_LEN 拍内这一路变过（自动衰减）。
//    这是给排线用的：转旋钮时两路都应该"热"，只有一个热就说明
//    那一路没接通。不占模式开关，正常使用时看不出来。
//======================================================================
module enc_dec #(
    parameter [15:0] DEB_N     = 16'd13500,       // 500us @ 27MHz
    parameter integer PER_STEP = 2,               // 走一格要几次同向跳变
    parameter [24:0] HOLD_LEN  = 25'd10800000     // 400ms @ 27MHz
)(
    input  wire clk,
    input  wire rst_n,
    input  wire s1_raw,
    input  wire s2_raw,
    output reg  step_up,        // 走一格：单拍脉冲
    output reg  step_dn,
    output wire act,            // 有跳变（单拍）—— 只用来点亮音量条
    output wire s1_level,       // 消抖后的 S1 电平
    output wire s2_level,       // 消抖后的 S2 电平
    output wire s1_hot,         // 最近 HOLD_LEN 内 S1 变过
    output wire s2_hot
);

    //------------------------------------------------------------------
    //  ① 消抖
    //------------------------------------------------------------------
    reg [15:0] c1, c2;
    reg        s1_db, s2_db;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            c1 <= 16'd0;  c2 <= 16'd0;
            s1_db <= 1'b1; s2_db <= 1'b1;          // 静止时被上拉，默认高
        end else begin
            if (s1_raw == s1_db) begin
                c1 <= 16'd0;
            end else if (c1 >= DEB_N) begin
                s1_db <= s1_raw;
                c1    <= 16'd0;
            end else begin
                c1 <= c1 + 16'd1;
            end

            if (s2_raw == s2_db) begin
                c2 <= 16'd0;
            end else if (c2 >= DEB_N) begin
                s2_db <= s2_raw;
                c2    <= 16'd0;
            end else begin
                c2 <= c2 + 16'd1;
            end
        end
    end

    assign s1_level = s1_db;
    assign s2_level = s2_db;

    //------------------------------------------------------------------
    //  ② 判方向
    //------------------------------------------------------------------
    wire [1:0] now_s = {s1_db, s2_db};
    reg  [1:0] prev_s;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) prev_s <= 2'b11;
        else        prev_s <= now_s;
    end

    wire chg = (prev_s != now_s);

    reg dir_cw, valid;

    always @* begin
        dir_cw = 1'b0;
        valid  = 1'b0;
        case ({prev_s, now_s})
            4'b00_01, 4'b01_11, 4'b11_10, 4'b10_00:
                begin dir_cw = 1'b1; valid = 1'b1; end     // 一个方向
            4'b00_10, 4'b10_11, 4'b11_01, 4'b01_00:
                begin dir_cw = 1'b0; valid = 1'b1; end     // 另一个方向
            default: ;                                     // 斜对角：留给下面
        endcase
    end

    //  上一次确定的方向。斜对角跳变（valid=0）沿用它，当作"继续转"，
    //  并且【把方向翻转一次】：这样若某种故障导致状态一直在 01<->10 或
    //  00<->11 之间来回跳（比如两根线接到同一个脚），就会一正一反
    //  互相抵消，不会一路往一个方向冲到顶。
    reg last_cw;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)    last_cw <= 1'b1;
        else if (chg)  last_cw <= valid ? dir_cw : ~last_cw;
    end

    wire this_cw = valid ? dir_cw : last_cw;

    wire cw_e  = chg &&  this_cw;
    wire ccw_e = chg && !this_cw;

    assign act = chg;

    //------------------------------------------------------------------
    //  ③ 攒够同向跳变 -> 走一格
    //------------------------------------------------------------------
    localparam [3:0] MID = 4'd8;

    reg [3:0] acc;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            acc     <= MID;
            step_up <= 1'b0;
            step_dn <= 1'b0;
        end else begin
            step_up <= 1'b0;
            step_dn <= 1'b0;

            if (cw_e) begin
                if (acc >= MID + PER_STEP - 1) begin
                    acc     <= MID;
                    step_up <= 1'b1;
                end else begin
                    acc <= acc + 4'd1;
                end
            end else if (ccw_e) begin
                if (acc <= MID - (PER_STEP - 1)) begin
                    acc     <= MID;
                    step_dn <= 1'b1;
                end else begin
                    acc <= acc - 4'd1;
                end
            end
        end
    end

    //------------------------------------------------------------------
    //  ④ 通道活动指示
    //------------------------------------------------------------------
    reg s1_p, s2_p;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            s1_p <= 1'b1;
            s2_p <= 1'b1;
        end else begin
            s1_p <= s1_db;
            s2_p <= s2_db;
        end
    end

    wire t1 = (s1_db != s1_p);
    wire t2 = (s2_db != s2_p);

    reg [24:0] h1, h2;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            h1 <= 25'd0;
            h2 <= 25'd0;
        end else begin
            if (t1)               h1 <= HOLD_LEN;
            else if (h1 != 25'd0) h1 <= h1 - 25'd1;

            if (t2)               h2 <= HOLD_LEN;
            else if (h2 != 25'd0) h2 <= h2 - 25'd1;
        end
    end

    assign s1_hot = (h1 != 25'd0);
    assign s2_hot = (h2 != 25'd0);

endmodule
