//======================================================================
//  test_osc.v  --  测试模式专用的纯正弦振荡器
//
//  和 dds_osc.v 的唯一区别：查的是 test_sine_rom（真正弦），
//  而不是 sine_rom（那个名字叫 sine，实测是钢琴音色波表，THD 57%）。
//
//  ---- 为什么不直接给 dds_osc 加个参数选表 ----
//    高云综合器【不会把两个相同的 ROM 合并成一份】（实测过），
//    所以 dds_osc 的 ROM 是硬写在里面的。测试模式要换表，
//    最省事的做法就是单独一个小模块，不用去动已经验好的 dds_osc。
//    （dds_osc 现在还是"钢琴音色"（voice.v）在用，别碰它。）
//
//  频率：f = phase_inc x fs / 2^32   （fs = 46875 Hz = 3MHz/64）
//        phase_inc = f x 2^32 / 46875   实测误差 < 0.02%
//======================================================================
module test_osc (
    input  wire               clk,
    input  wire               rst_n,
    input  wire               tick,        // 1 clk 脉冲，每个采样周期一次
    input  wire [31:0]        phase_inc,   // 频率控制字
    output wire signed [15:0] wave
);

    reg [31:0] phase;

    always @(posedge clk or negedge rst_n)
        if (!rst_n)    phase <= 32'd0;
        else if (tick) phase <= phase + phase_inc;

    test_sine_rom u_rom (
        .clk  (clk),
        .addr (phase[31:22]),   // 取高 10 位 -> 1024 点表，正好一个整周期
        .dout (wave)
    );

endmodule
