//======================================================================
//  voice.v  --  一个完整的合成声部
//
//  一个"声部" = 一个完整的振荡器 + 一路独立包络：
//      DDS 波表振荡器  ->  门控 ADSR 包络  ->  电平归一化
//
//  这是赛题评分规则里"独立发声单元"的定义：
//  包含独立相位累加器、独立频率调控、独立包络控制。
//
//  参数（A_DIV/D_DIV/R_DIV/ENV_SUS）可以逐个声部不同，
//  比如旋律音可以用短促的包络、和弦音用柔和的包络。
//
//  注意：R_DIV 决定了"收音"要花多久（约 R_DIV × ENV_SUS 个时钟），
//  调用方必须保证给门的关闭时刻留够这么久，否则包络归不了零。
//======================================================================
module voice #(
    parameter signed [15:0] ENV_SUS = 16'sd22937,   // 延音电平 = 0.70 × 32767
    parameter [9:0] A_DIV = 10'd8,                  // 起音步长分频 -> 约  9.7ms
    parameter [9:0] D_DIV = 10'd412,                // 衰减步长分频 -> 约 150ms
    parameter [9:0] R_DIV = 10'd141                 // 收音步长分频 -> 约 120ms
)(
    input  wire               clk,
    input  wire               rst_n,
    input  wire               tick,        // 1 clk 脉冲，每个采样周期一次
    input  wire               gate,        // 门：高 = 发声，低 = 收音
    input  wire [31:0]        phase_inc,   // 频率控制字
    output wire signed [15:0] sample       // 该声部的输出
);

    localparam signed [15:0] ENV_PEAK = 16'sd32767;

    //----------- 振荡器 -----------
    wire signed [15:0] wave;

    dds_osc u_osc (
        .clk       (clk),
        .rst_n     (rst_n),
        .tick      (tick),
        .phase_inc (phase_inc),
        .wave      (wave)
    );

    //----------- 门控 ADSR 包络 -----------
    localparam [2:0] S_IDL = 3'd0;
    localparam [2:0] S_ATK = 3'd1;
    localparam [2:0] S_DEC = 3'd2;
    localparam [2:0] S_SUS = 3'd3;
    localparam [2:0] S_REL = 3'd4;

    reg [2:0]         env_state;
    reg signed [15:0] env;
    reg [9:0]         env_div;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            env_state <= S_IDL;
            env       <= 16'sd0;
            env_div   <= 10'd0;
        end else begin
            case (env_state)
                S_IDL: begin
                    env_div <= 10'd0;
                    env     <= 16'sd0;
                    if (gate) env_state <= S_ATK;
                end
                S_ATK: begin
                    if (!gate) begin
                        env_state <= S_REL;
                    end else if (env_div == (A_DIV - 10'd1)) begin
                        env_div <= 10'd0;
                        if (env >= ENV_PEAK) env_state <= S_DEC;
                        else                 env       <= env + 16'sd1;
                    end else begin
                        env_div <= env_div + 10'd1;
                    end
                end
                S_DEC: begin
                    if (!gate) begin
                        env_state <= S_REL;
                    end else if (env_div == (D_DIV - 10'd1)) begin
                        env_div <= 10'd0;
                        if (env <= ENV_SUS) env_state <= S_SUS;
                        else                env       <= env - 16'sd1;
                    end else begin
                        env_div <= env_div + 10'd1;
                    end
                end
                S_SUS: begin
                    env_div <= 10'd0;
                    if (!gate) env_state <= S_REL;
                end
                S_REL: begin
                    if (gate) begin
                        env_state <= S_ATK;         // 还没收完又被按下 -> 重新起音
                    end else if (env_div == (R_DIV - 10'd1)) begin
                        env_div <= 10'd0;
                        if (env <= 16'sd0) begin
                            env       <= 16'sd0;
                            env_state <= S_IDL;
                        end else begin
                            env <= env - 16'sd1;
                        end
                    end else begin
                        env_div <= env_div + 10'd1;
                    end
                end
                default: begin
                    env_state <= S_IDL;
                    env_div   <= 10'd0;
                end
            endcase
        end
    end

    //----------- 包络相乘（打一拍帮助时序收敛）-----------
    reg signed [31:0] mul;

    always @(posedge clk) mul <= wave * env;

    assign sample = mul[30:15];      // >> 15 归一化

endmodule
