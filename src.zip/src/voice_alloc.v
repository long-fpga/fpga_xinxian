//======================================================================
//  voice_alloc.v  --  16 个键 -> 4 个声部 的分配器
//
//  策略：按下就分配一个空闲声部、门拉高；松开就立刻标记空闲、门拉低；
//        4 个都占着时忽略新键，不抢占（4 就是设计上的上限）。
//
//  ★ "松开立刻空闲"是安全的：voice.v 的 S_REL 里有 `if (gate) -> S_ATK`，
//    还在收音的声部被新键占用时【从当前 env 继续起音】，不会跳回 0 也不咔哒，
//    所以不需要"等收音走完"的额外状态机。
//
//  ★ 每个时钟只做一件事：释放优先、分配延后一拍。否则两者会争同一个声部。
//    27MHz 下按键是极慢事件，晚 37ns 无感，换来逻辑上不可能竞争。
//
//  输出 k0..k3 = 各声部拿着第几个键（0..14），4'hF = 空闲。
//  （15 号键是八度切换键，不参与发声，所以键号只到 14。）
//======================================================================
module voice_alloc (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [15:0] keys,        // bit k = 第 k 个键按下
    output wire [3:0]  gate,        // 4 个声部的门
    output wire [3:0]  k0,
    output wire [3:0]  k1,
    output wire [3:0]  k2,
    output wire [3:0]  k3
);

    localparam [3:0] NONE = 4'hF;   // "这个声部空闲"的键号

    reg [3:0] owner [0:3];          // owner[i] = 声部 i 拿着的键号
    reg [3:0] g;                    // 4 个门

    integer i;

    //------------------------------------------------------------------
    //  组合 1：找一个空闲声部。倒着扫、后写覆盖先写 -> 最小下标优先。
    //------------------------------------------------------------------
    reg [3:0] fs;
    always @* begin
        fs = NONE;
        for (i = 3; i >= 0; i = i - 1)
            if (owner[i] == NONE) fs = i[3:0];
    end

    //------------------------------------------------------------------
    //  组合 2：找"按下了但没人负责"的键。倒着扫 -> 键号小的优先。
    //  4 路比较刻意写开、不用函数（本项目踩过 Gowin 常量折叠的坑）。
    //
    //  ★ 只扫 0..13，不扫 14/15 —— 这两个键现在是【音量键】（S15 调小 / S16 调大），
    //    不是音符键，让 voice_alloc 去分配它们会把音量键吃成发声。
    //    代价：键盘音域从"低音1~高音1"缩到"低音1~中音7"（少了最高那个音）。
    //------------------------------------------------------------------
    localparam [3:0] TOP_KEY = 4'd15;      // 最高的【音符】键号（16 个音：低音1~高音2）
    reg [3:0] wk;
    reg       hw;
    always @* begin
        wk = 4'd0;
        hw = 1'b0;
        for (i = TOP_KEY; i >= 0; i = i - 1)
            if (keys[i] && !((owner[0] == i) | (owner[1] == i) |
                             (owner[2] == i) | (owner[3] == i)))
                begin hw = 1'b1; wk = i[3:0]; end
    end

    //------------------------------------------------------------------
    //  组合 3：找"它负责的键已经松开"的声部。倒着扫 -> 最小下标优先。
    //  ★ owner[i] != NONE 必须有：空闲声部的 owner 是 4'hF，而 NONE 会索引到
    //    keys[15] —— 那个键是【音色键】，不是音符键（下面找键的循环只扫 0..14），
    //    不挡住的话空闲声部会被误判成"键松开了"。
    //------------------------------------------------------------------
    reg [3:0] rel;
    reg       hr;
    always @* begin
        rel = NONE;
        hr  = 1'b0;
        for (i = 3; i >= 0; i = i - 1)
            if ((owner[i] != NONE) && !keys[owner[i]])
                begin hr = 1'b1; rel = i[3:0]; end
    end

    //------------------------------------------------------------------
    //  时序：释放优先、分配其次。写成显式 case 而不是变量下标写存储器，
    //  对综合器最友好（本项目出过几次"仿真对、综合不对"）。
    //------------------------------------------------------------------
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            owner[0] <= NONE; owner[1] <= NONE;
            owner[2] <= NONE; owner[3] <= NONE;
            g        <= 4'd0;
        end else if (hr) begin
            case (rel)
                2'd0:    begin owner[0] <= NONE; g[0] <= 1'b0; end
                2'd1:    begin owner[1] <= NONE; g[1] <= 1'b0; end
                2'd2:    begin owner[2] <= NONE; g[2] <= 1'b0; end
                default: begin owner[3] <= NONE; g[3] <= 1'b0; end
            endcase
        end else if (hw && (fs != NONE)) begin
            // fs==NONE 说明 4 个声部都占着 -> 忽略这个键（不抢占）
            case (fs)
                2'd0:    begin owner[0] <= wk; g[0] <= 1'b1; end
                2'd1:    begin owner[1] <= wk; g[1] <= 1'b1; end
                2'd2:    begin owner[2] <= wk; g[2] <= 1'b1; end
                default: begin owner[3] <= wk; g[3] <= 1'b1; end
            endcase
        end
    end

    assign gate = g;
    assign k0   = owner[0];
    assign k1   = owner[1];
    assign k2   = owner[2];
    assign k3   = owner[3];

endmodule
